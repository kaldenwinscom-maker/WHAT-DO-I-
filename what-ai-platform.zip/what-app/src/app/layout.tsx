import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "WHAT — AI Agency Platform",
  description: "Deploy AI employees for marketing, sales, support, and operations. Custom prompts, multi-model chat, agent fusion, and workflow automation.",
  keywords: ["AI", "agency", "automation", "Claude", "GPT-4", "Gemini", "SaaS"],
  openGraph: {
    title: "WHAT — AI Agency Platform",
    description: "Scale your business with AI employees.",
    type: "website",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
  themeColor: "#060810",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="WHAT" />
      </head>
      <body>{children}</body>
    </html>
  );
}
