"use client";

import { useState, useEffect, useRef, useCallback } from "react";



// ─── ICONS ────────────────────────────────────────────────────────────────────
const Icon = ({ name, size = 18, color = "currentColor" }) => {
  const icons = {
    brain: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96-.46 2.5 2.5 0 0 1-1.98-3 2.5 2.5 0 0 1-1.32-4.24 3 3 0 0 1 .34-5.58 2.5 2.5 0 0 1 1.96-3.11A2.5 2.5 0 0 1 9.5 2Z"/><path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96-.46 2.5 2.5 0 0 0 1.98-3 2.5 2.5 0 0 0 1.32-4.24 3 3 0 0 0-.34-5.58 2.5 2.5 0 0 0-1.96-3.11A2.5 2.5 0 0 0 14.5 2Z"/></svg>,
    zap: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>,
    users: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>,
    chart: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>,
    message: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>,
    workflow: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><rect x="3" y="3" width="5" height="5" rx="1"/><rect x="16" y="3" width="5" height="5" rx="1"/><rect x="16" y="16" width="5" height="5" rx="1"/><path d="M5.5 8v3c0 1.1.9 2 2 2H12"/><path d="M12 13h1.5a2 2 0 0 1 2 2v1"/><path d="M12 13V8"/></svg>,
    settings: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>,
    home: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>,
    file: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>,
    crm: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>,
    send: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>,
    plus: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
    x: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
    check: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>,
    arrow: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>,
    crown: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M2 4l3 12h14l3-12-6 7-4-7-4 7-6-7z"/><path d="M5 20h14"/></svg>,
    robot: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><rect x="3" y="11" width="18" height="10" rx="2"/><circle cx="12" cy="5" r="2"/><path d="M12 7v4"/><line x1="8" y1="16" x2="8" y2="16"/><line x1="16" y1="16" x2="16" y2="16"/><path d="M9 19h6"/></svg>,
    trending: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>,
    bell: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>,
    search: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>,
    upload: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/></svg>,
    mic: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>,
    star: <svg width={size} height={size} viewBox="0 0 24 24" fill={color} stroke={color} strokeWidth="0"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>,
    logout: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>,
    menu: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>,
    copy: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>,
    refresh: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-4.95"/></svg>,
    shield: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>,
    globe: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>,
    code: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>,
  };
  return icons[name] || null;
};

// ─── ANIMATED BACKGROUND ─────────────────────────────────────────────────────
const AnimatedBg = () => (
  <div style={{ position: "fixed", inset: 0, zIndex: 0, overflow: "hidden", pointerEvents: "none" }}>
    <div style={{
      position: "absolute", width: 600, height: 600, borderRadius: "50%",
      background: "radial-gradient(circle, rgba(108,99,255,0.12) 0%, transparent 70%)",
      top: "-200px", left: "-100px", animation: "morph 12s ease-in-out infinite"
    }}/>
    <div style={{
      position: "absolute", width: 500, height: 500, borderRadius: "50%",
      background: "radial-gradient(circle, rgba(0,212,170,0.08) 0%, transparent 70%)",
      bottom: "-100px", right: "-100px", animation: "morph 16s ease-in-out infinite reverse"
    }}/>
    <div style={{
      position: "absolute", inset: 0,
      backgroundImage: `radial-gradient(circle at 1px 1px, rgba(255,255,255,0.03) 1px, transparent 0)`,
      backgroundSize: "40px 40px"
    }}/>
  </div>
);

// ─── NAVBAR ───────────────────────────────────────────────────────────────────
const Navbar = ({ onNav, page }) => {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", h);
    return () => window.removeEventListener("scroll", h);
  }, []);

  return (
    <nav style={{
      position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
      padding: "0 32px",
      background: scrolled ? "rgba(6,8,16,0.85)" : "transparent",
      backdropFilter: scrolled ? "blur(20px)" : "none",
      borderBottom: scrolled ? "1px solid var(--border)" : "none",
      transition: "all 0.3s",
      display: "flex", alignItems: "center", justifyContent: "space-between",
      height: "calc(68px + env(safe-area-inset-top, 0px))",
      paddingTop: "env(safe-area-inset-top, 0px)"
    }}>
      <div onClick={() => onNav("landing")} style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer" }}>
        <div style={{
          width: 36, height: 36, borderRadius: 10,
          background: "linear-gradient(135deg, var(--accent), var(--accent2))",
          display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "0 4px 16px var(--glow)"
        }}>
          <Icon name="brain" size={18} color="#fff"/>
        </div>
        <span style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: 18, letterSpacing: "-0.5px" }}>
          WHAT
        </span>
      </div>
      <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
        {["Features", "Pricing", "Agents"].map(item => (
          <button key={item} style={{
            background: "none", border: "none", color: "var(--text2)", fontSize: 14,
            padding: "8px 14px", cursor: "pointer", borderRadius: 8, transition: "all 0.2s",
            fontFamily: "DM Sans, sans-serif"
          }}
          onMouseEnter={e => e.target.style.color = "var(--text)"}
          onMouseLeave={e => e.target.style.color = "var(--text2)"}
          >{item}</button>
        ))}
        <button className="btn btn-ghost" style={{ marginLeft: 8 }} onClick={() => onNav("dashboard")}>
          Log in
        </button>
        <button className="btn btn-primary" onClick={() => onNav("dashboard")}>
          Get Started <Icon name="arrow" size={14}/>
        </button>
      </div>
    </nav>
  );
};

// ─── LANDING PAGE ─────────────────────────────────────────────────────────────
const LandingPage = ({ onNav }) => {
  const features = [
    { icon: "brain", title: "Multi-Model AI", desc: "Switch between GPT-4, Claude, and Gemini seamlessly for best results", color: "var(--accent)" },
    { icon: "workflow", title: "Workflow Automation", desc: "Build powerful automations with triggers, actions, and conditions", color: "var(--accent2)" },
    { icon: "users", title: "Team Collaboration", desc: "Invite team members, share workspaces, and manage permissions", color: "#a78bfa" },
    { icon: "shield", title: "Enterprise Security", desc: "SOC2 compliant with end-to-end encryption and role-based access", color: "var(--accent4)" },
    { icon: "chart", title: "Deep Analytics", desc: "Real-time insights on AI usage, ROI, and team productivity", color: "var(--accent3)" },
    { icon: "code", title: "API First", desc: "Full REST API and webhooks to integrate with any system", color: "#34d399" },
  ];

  const agents = [
    { name: "Marketing AI", emoji: "📣", color: "#6c63ff", desc: "Campaigns, copy, strategy" },
    { name: "Sales AI", emoji: "💰", color: "#00d4aa", desc: "Outreach, follow-ups, CRM" },
    { name: "Research AI", emoji: "🔬", color: "#f5a623", desc: "Analysis, summaries, reports" },
    { name: "Support AI", emoji: "💬", color: "#ff6b6b", desc: "Tickets, FAQs, responses" },
    { name: "Social AI", emoji: "📱", color: "#a78bfa", desc: "Posts, captions, strategy" },
    { name: "Copy AI", emoji: "✍️", color: "#34d399", desc: "Blog, email, ad copy" },
  ];

  const plans = [
    { name: "Starter", price: "0", period: "Free forever", features: ["3 AI Agents", "100 messages/mo", "Basic templates", "1 user"], cta: "Get Started", highlight: false },
    { name: "Pro", price: "49", period: "per month", features: ["15 AI Agents", "Unlimited messages", "Workflow automation", "5 team members", "Priority support", "Analytics dashboard"], cta: "Start Free Trial", highlight: true },
    { name: "Agency", price: "149", period: "per month", features: ["Unlimited Agents", "Unlimited messages", "White-label option", "25 team members", "Custom integrations", "Dedicated support", "SLA guarantee"], cta: "Contact Sales", highlight: false },
  ];

  const testimonials = [
    { name: "Sarah Chen", role: "CMO at TechFlow", avatar: "SC", text: "WHAT reduced our content production time by 80%. The marketing agent is unreal.", rating: 5 },
    { name: "Marcus Rodriguez", role: "Founder, Veloce", avatar: "MR", text: "Replaced 3 SaaS tools with WHAT. The workflow automation is next level.", rating: 5 },
    { name: "Priya Sharma", role: "Head of Growth, Apex", avatar: "PS", text: "Our sales team closes 40% more deals since using the Sales AI agent daily.", rating: 5 },
  ];

  return (
    <div style={{ position: "relative", zIndex: 1 }}>
      {/* Hero */}
      <section style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: "calc(120px + env(safe-area-inset-top, 0px)) 24px 80px", textAlign: "center" }}>
        <div style={{ maxWidth: 780, animation: "slide-up 0.8s cubic-bezier(0.22,1,0.36,1) both" }}>
          <div className="tag glass2" style={{ marginBottom: 24, display: "inline-flex", color: "var(--accent2)", border: "1px solid rgba(0,212,170,0.3)" }}>
            <Icon name="zap" size={12} color="var(--accent2)"/> Now with Claude 4 + GPT-4o
          </div>
          <h1 style={{ fontSize: "clamp(42px,6vw,78px)", fontWeight: 800, lineHeight: 1.06, letterSpacing: "-3px", marginBottom: 24 }}>
            Scale Your Business<br/>
            <span style={{
              background: "linear-gradient(135deg, var(--accent), var(--accent2), #a78bfa)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
              backgroundClip: "text"
            }}>With AI Employees</span>
          </h1>
          <p style={{ fontSize: 19, color: "var(--text2)", lineHeight: 1.7, marginBottom: 40, maxWidth: 560, margin: "0 auto 40px" }}>
            Deploy intelligent AI agents that handle marketing, sales, support, and operations — all in one unified workspace.
          </p>
          <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
            <button className="btn btn-primary" style={{ fontSize: 16, padding: "14px 32px" }} onClick={() => onNav("dashboard")}>
              Start Free Today <Icon name="arrow" size={16}/>
            </button>
            <button className="btn btn-ghost" style={{ fontSize: 16, padding: "14px 32px" }}>
              Watch Demo ▶
            </button>
          </div>
          <div style={{ marginTop: 56, display: "flex", gap: 40, justifyContent: "center", flexWrap: "wrap" }}>
            {[["12K+", "Active teams"], ["94M+", "AI messages"], ["99.9%", "Uptime SLA"]].map(([n, l]) => (
              <div key={l} style={{ textAlign: "center" }}>
                <div style={{ fontSize: 28, fontWeight: 800, fontFamily: "Syne, sans-serif", background: "linear-gradient(135deg, var(--text), var(--text2))", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>{n}</div>
                <div style={{ fontSize: 13, color: "var(--text3)" }}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Floating UI Preview */}
      <section style={{ padding: "0 16px 60px" }}>
        <div style={{ maxWidth: 1000, margin: "0 auto", position: "relative" }}>
          <div className="glass2" style={{ borderRadius: var_r3, overflow: "hidden", boxShadow: "0 40px 100px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.06)" }}>
            <DashboardPreview onNav={onNav}/>
          </div>
          <div style={{ position: "absolute", inset: -1, borderRadius: 30, background: "linear-gradient(135deg, rgba(108,99,255,0.3), transparent, rgba(0,212,170,0.2))", zIndex: -1, filter: "blur(40px)" }}/>
        </div>
      </section>

      {/* Features */}
      <section style={{ padding: "80px 32px", maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 60 }}>
          <div className="tag glass" style={{ marginBottom: 16, display: "inline-flex", color: "var(--text2)" }}>Features</div>
          <h2 style={{ fontSize: "clamp(28px,4vw,48px)", fontWeight: 800, letterSpacing: "-1.5px", marginBottom: 16 }}>Everything your team needs</h2>
          <p style={{ color: "var(--text2)", fontSize: 16, maxWidth: 480, margin: "0 auto" }}>Built for modern teams that want to move faster without sacrificing quality.</p>
        </div>
        <div className="grid-3" style={{ gap: 20 }}>
          {features.map((f, i) => (
            <div key={f.title} className="glass" style={{
              padding: 28, borderRadius: var_r2,
              animation: `slide-up 0.6s cubic-bezier(0.22,1,0.36,1) ${i * 0.08}s both`,
              transition: "transform 0.2s, border-color 0.2s",
              cursor: "default"
            }}
            onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.borderColor = "var(--border2)"; }}
            onMouseLeave={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.borderColor = "var(--border)"; }}
            >
              <div style={{ width: 44, height: 44, borderRadius: 12, background: f.color + "20", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 16 }}>
                <Icon name={f.icon} size={20} color={f.color}/>
              </div>
              <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 8 }}>{f.title}</h3>
              <p style={{ color: "var(--text2)", fontSize: 14, lineHeight: 1.6 }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* AI Agents */}
      <section style={{ padding: "80px 32px", maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 60 }}>
          <h2 style={{ fontSize: "clamp(28px,4vw,48px)", fontWeight: 800, letterSpacing: "-1.5px", marginBottom: 16 }}>Meet your AI team</h2>
          <p style={{ color: "var(--text2)", fontSize: 16 }}>Specialized agents trained for every business function.</p>
        </div>
        <div className="grid-3" style={{ gap: 16 }}>
          {agents.map((a, i) => (
            <div key={a.name} className="glass" style={{
              padding: "24px 28px", borderRadius: var_r2, display: "flex", alignItems: "center", gap: 16,
              cursor: "pointer", transition: "all 0.2s",
              animation: `slide-up 0.6s cubic-bezier(0.22,1,0.36,1) ${i * 0.08}s both`
            }}
            onClick={() => onNav("agents")}
            onMouseEnter={e => { e.currentTarget.style.background = "var(--surface2)"; e.currentTarget.style.borderColor = "var(--border2)"; }}
            onMouseLeave={e => { e.currentTarget.style.background = "var(--surface)"; e.currentTarget.style.borderColor = "var(--border)"; }}
            >
              <div style={{ width: 48, height: 48, borderRadius: 14, background: a.color + "20", border: `1px solid ${a.color}30`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 }}>
                {a.emoji}
              </div>
              <div>
                <div style={{ fontSize: 15, fontWeight: 600 }}>{a.name}</div>
                <div style={{ fontSize: 13, color: "var(--text3)" }}>{a.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section style={{ padding: "80px 32px", maxWidth: 1000, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 60 }}>
          <h2 style={{ fontSize: "clamp(28px,4vw,48px)", fontWeight: 800, letterSpacing: "-1.5px", marginBottom: 16 }}>Simple, transparent pricing</h2>
          <p style={{ color: "var(--text2)" }}>Start free. Scale as you grow. No hidden fees.</p>
        </div>
        <div className="grid-3" style={{ gap: 20, alignItems: "stretch" }}>
          {plans.map((p, i) => (
            <div key={p.name} style={{
              padding: 32, borderRadius: var_r2,
              background: p.highlight ? "linear-gradient(135deg, rgba(108,99,255,0.15), rgba(108,99,255,0.05))" : "var(--surface)",
              border: p.highlight ? "1px solid rgba(108,99,255,0.4)" : "1px solid var(--border)",
              position: "relative", overflow: "hidden",
              animation: `slide-up 0.6s cubic-bezier(0.22,1,0.36,1) ${i * 0.1}s both`,
              boxShadow: p.highlight ? "0 0 60px rgba(108,99,255,0.15)" : "none"
            }}>
              {p.highlight && (
                <div style={{ position: "absolute", top: 16, right: 16 }}>
                  <span className="tag" style={{ background: "var(--accent)", color: "#fff", fontSize: 11 }}>Most Popular</span>
                </div>
              )}
              <div style={{ marginBottom: 24 }}>
                <div style={{ fontSize: 13, color: "var(--text2)", marginBottom: 8, textTransform: "uppercase", letterSpacing: "1px" }}>{p.name}</div>
                <div style={{ display: "flex", alignItems: "baseline", gap: 4 }}>
                  <span style={{ fontSize: 14, color: "var(--text2)" }}>$</span>
                  <span style={{ fontSize: 48, fontWeight: 800, fontFamily: "Syne, sans-serif", letterSpacing: "-2px" }}>{p.price}</span>
                  <span style={{ fontSize: 13, color: "var(--text3)" }}>{p.period}</span>
                </div>
              </div>
              <div style={{ marginBottom: 32 }}>
                {p.features.map(f => (
                  <div key={f} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                    <div style={{ width: 18, height: 18, borderRadius: "50%", background: p.highlight ? "rgba(108,99,255,0.2)" : "rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                      <Icon name="check" size={10} color={p.highlight ? "var(--accent)" : "var(--text3)"}/>
                    </div>
                    <span style={{ fontSize: 14, color: "var(--text2)" }}>{f}</span>
                  </div>
                ))}
              </div>
              <button className={`btn ${p.highlight ? "btn-primary" : "btn-ghost"}`} style={{ width: "100%", justifyContent: "center" }} onClick={() => onNav("dashboard")}>
                {p.cta}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section style={{ padding: "80px 32px", maxWidth: 1000, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 60 }}>
          <h2 style={{ fontSize: "clamp(28px,4vw,48px)", fontWeight: 800, letterSpacing: "-1.5px", marginBottom: 16 }}>Loved by teams worldwide</h2>
        </div>
        <div className="grid-3" style={{ gap: 20 }}>
          {testimonials.map((t, i) => (
            <div key={t.name} className="glass" style={{
              padding: 28, borderRadius: var_r2,
              animation: `slide-up 0.6s cubic-bezier(0.22,1,0.36,1) ${i * 0.1}s both`
            }}>
              <div style={{ display: "flex", gap: 2, marginBottom: 16 }}>
                {Array(t.rating).fill(0).map((_, j) => <Icon key={j} name="star" size={14} color="#f5a623"/>)}
              </div>
              <p style={{ fontSize: 14, color: "var(--text2)", lineHeight: 1.7, marginBottom: 20 }}>"{t.text}"</p>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ width: 36, height: 36, borderRadius: "50%", background: "linear-gradient(135deg, var(--accent), var(--accent2))", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700 }}>
                  {t.avatar}
                </div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{t.name}</div>
                  <div style={{ fontSize: 12, color: "var(--text3)" }}>{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: "80px 32px 120px" }}>
        <div style={{ maxWidth: 600, margin: "0 auto", textAlign: "center" }}>
          <div className="glass2" style={{ padding: "60px 48px", borderRadius: 32, position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", inset: 0, background: "radial-gradient(circle at 50% 50%, rgba(108,99,255,0.15), transparent 70%)", pointerEvents: "none" }}/>
            <h2 style={{ fontSize: "clamp(24px,3vw,38px)", fontWeight: 800, letterSpacing: "-1px", marginBottom: 16, position: "relative" }}>
              Ready to build your AI team?
            </h2>
            <p style={{ color: "var(--text2)", marginBottom: 32, position: "relative" }}>Join 12,000+ teams already using WHAT to scale their business.</p>
            <button className="btn btn-primary" style={{ fontSize: 16, padding: "14px 36px", position: "relative" }} onClick={() => onNav("dashboard")}>
              Start For Free — No Credit Card <Icon name="arrow" size={16}/>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

// Hack for CSS vars in JSX inline styles
const var_r2 = "var(--r2)";
const var_r3 = "var(--r3)";

// ─── DASHBOARD PREVIEW (used in landing) ─────────────────────────────────────
const DashboardPreview = ({ onNav }) => (
  <div style={{ background: "var(--bg2)", padding: "0" }}>
    {/* Mock title bar */}
    <div style={{ padding: "14px 20px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 8 }}>
      {["#ff5f56","#ffbd2e","#27c93f"].map(c => <div key={c} style={{ width: 12, height: 12, borderRadius: "50%", background: c }}/>)}
      <span style={{ fontSize: 12, color: "var(--text3)", marginLeft: 8 }}>WHAT Dashboard</span>
    </div>
    <div style={{ display: "flex", height: 320 }}>
      {/* Sidebar */}
      <div style={{ width: 160, padding: "16px 12px", borderRight: "1px solid var(--border)", flexShrink: 0 }}>
        {[
          { icon: "home", label: "Dashboard", active: true },
          { icon: "robot", label: "Agents" },
          { icon: "message", label: "Chat" },
          { icon: "workflow", label: "Workflows" },
          { icon: "chart", label: "Analytics" },
        ].map(item => (
          <div key={item.label} style={{
            display: "flex", alignItems: "center", gap: 8, padding: "8px 10px",
            borderRadius: 8, marginBottom: 2,
            background: item.active ? "rgba(108,99,255,0.15)" : "transparent",
            cursor: "pointer"
          }} onClick={() => onNav && onNav("dashboard")}>
            <Icon name={item.icon} size={13} color={item.active ? "var(--accent)" : "var(--text3)"}/>
            <span style={{ fontSize: 12, color: item.active ? "var(--accent)" : "var(--text3)" }}>{item.label}</span>
          </div>
        ))}
      </div>
      {/* Main */}
      <div style={{ flex: 1, padding: 20, overflow: "hidden" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12, marginBottom: 16 }}>
          {[["$24,820", "Revenue", "+18%"], ["1.2M", "AI Tokens", "+34%"], ["847", "Tasks Done", "+12%"]].map(([v,l,c]) => (
            <div key={l} className="glass" style={{ padding: "14px 16px", borderRadius: 10 }}>
              <div style={{ fontSize: 10, color: "var(--text3)", marginBottom: 6 }}>{l}</div>
              <div style={{ fontSize: 18, fontWeight: 700, fontFamily: "Syne, sans-serif" }}>{v}</div>
              <div style={{ fontSize: 10, color: "var(--accent2)", marginTop: 4 }}>↑ {c}</div>
            </div>
          ))}
        </div>
        <div className="glass" style={{ borderRadius: 12, padding: 16, height: 160, display: "flex", flexDirection: "column", gap: 10 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: "var(--text2)" }}>AI Activity</div>
          <div style={{ flex: 1, display: "flex", alignItems: "flex-end", gap: 4 }}>
            {[40,65,30,80,55,90,45,70,35,85,60,95].map((h, i) => (
              <div key={i} style={{
                flex: 1, height: `${h}%`, borderRadius: "3px 3px 0 0",
                background: `linear-gradient(to top, var(--accent)${i % 3 === 0 ? "" : "80"}, var(--accent2)${i % 3 === 0 ? "60" : "20"})`,
                transition: "height 0.3s"
              }}/>
            ))}
          </div>
        </div>
      </div>
    </div>
  </div>
);

// ─── SIDEBAR ──────────────────────────────────────────────────────────────────
// ─── USE MOBILE HOOK ─────────────────────────────────────────────────────────
const useIsMobile = () => {
  const [isMobile, setIsMobile] = useState(
    typeof window !== "undefined" ? window.innerWidth <= 768 : false
  );
  useEffect(() => {
    const handler = () => setIsMobile(window.innerWidth <= 768);
    window.addEventListener("resize", handler);
    return () => window.removeEventListener("resize", handler);
  }, []);
  return isMobile;
};

// ─── MOBILE DRAWER ────────────────────────────────────────────────────────────
const MobileDrawer = ({ page, onNav, onClose }) => {
  const navItems = [
    { id: "dashboard", icon: "home", label: "Dashboard" },
    { id: "agents", icon: "robot", label: "AI Agents" },
    { id: "chat", icon: "message", label: "Chat" },
    { id: "workflows", icon: "workflow", label: "Workflows" },
    { id: "crm", icon: "crm", label: "CRM" },
    { id: "files", icon: "file", label: "Files" },
    { id: "analytics", icon: "chart", label: "Analytics" },
    { id: "settings", icon: "settings", label: "Settings" },
  ];
  return (
    <>
      <div className="drawer-overlay" onClick={onClose}/>
      <div className="drawer">
        <div style={{ padding: "20px 16px 16px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 32, height: 32, borderRadius: 9, background: "linear-gradient(135deg, var(--accent), var(--accent2))", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 4px 12px var(--glow)" }}>
              <Icon name="brain" size={16} color="#fff"/>
            </div>
            <span style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: 14 }}>WHAT</span>
          </div>
          <button className="btn btn-ghost" style={{ padding: "6px 8px" }} onClick={onClose}><Icon name="x" size={16}/></button>
        </div>
        <nav style={{ flex: 1, padding: "12px 10px", overflowY: "auto", WebkitOverflowScrolling: "touch" }}>
          {navItems.map(item => {
            const active = page === item.id;
            return (
              <div key={item.id} onClick={() => { onNav(item.id); onClose(); }} style={{
                display: "flex", alignItems: "center", gap: 12,
                padding: "13px 14px", borderRadius: 10, marginBottom: 2, cursor: "pointer",
                background: active ? "rgba(108,99,255,0.15)" : "transparent",
                borderLeft: active ? "2px solid var(--accent)" : "2px solid transparent",
              }}>
                <Icon name={item.icon} size={18} color={active ? "var(--accent)" : "var(--text3)"}/>
                <span style={{ fontSize: 15, color: active ? "var(--text)" : "var(--text2)", fontWeight: active ? 500 : 400 }}>{item.label}</span>
              </div>
            );
          })}
        </nav>
        <div style={{ padding: "12px 10px", borderTop: "1px solid var(--border)", flexShrink: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", borderRadius: 10, cursor: "pointer" }} onClick={() => { onNav("landing"); onClose(); }}>
            <div style={{ width: 32, height: 32, borderRadius: "50%", background: "linear-gradient(135deg, var(--accent), var(--accent2))", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700, flexShrink: 0 }}>JD</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 500 }}>John Doe</div>
              <div style={{ fontSize: 11, color: "var(--text3)" }}>Pro Plan</div>
            </div>
            <Icon name="logout" size={14} color="var(--text3)"/>
          </div>
        </div>
      </div>
    </>
  );
};

// ─── BOTTOM NAV (mobile) ──────────────────────────────────────────────────────
const BottomNav = ({ page, onNav }) => {
  const items = [
    { id: "dashboard", icon: "home", label: "Home" },
    { id: "chat", icon: "message", label: "Chat" },
    { id: "agents", icon: "robot", label: "Agents" },
    { id: "workflows", icon: "workflow", label: "Flows" },
    { id: "settings", icon: "settings", label: "More" },
  ];
  return (
    <div className="bottom-nav">
      {items.map(item => {
        const active = page === item.id;
        return (
          <div key={item.id} className="bottom-nav-item" onClick={() => onNav(item.id)}>
            <Icon name={item.icon} size={20} color={active ? "var(--accent)" : "var(--text3)"}/>
            <span style={{ fontSize: 10, color: active ? "var(--accent)" : "var(--text3)", fontWeight: active ? 600 : 400 }}>{item.label}</span>
            {active && <div style={{ width: 4, height: 4, borderRadius: "50%", background: "var(--accent)", position: "absolute", bottom: "calc(10px + env(safe-area-inset-bottom, 0px))" }}/>}
          </div>
        );
      })}
    </div>
  );
};

const Sidebar = ({ page, onNav, collapsed, onToggle }) => {
  const navItems = [
    { id: "dashboard", icon: "home", label: "Dashboard" },
    { id: "agents", icon: "robot", label: "AI Agents" },
    { id: "chat", icon: "message", label: "Chat" },
    { id: "workflows", icon: "workflow", label: "Workflows" },
    { id: "crm", icon: "crm", label: "CRM" },
    { id: "files", icon: "file", label: "Files" },
    { id: "analytics", icon: "chart", label: "Analytics" },
    { id: "settings", icon: "settings", label: "Settings" },
  ];

  return (
    <aside style={{
      width: collapsed ? 64 : 220, flexShrink: 0,
      background: "var(--bg2)", borderRight: "1px solid var(--border)",
      display: "flex", flexDirection: "column", height: "100vh",
      position: "sticky", top: 0, transition: "width 0.25s cubic-bezier(0.4,0,0.2,1)",
      zIndex: 50, overflow: "hidden"
    }}>
      <div style={{ padding: "20px 16px 16px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 10, flexShrink: 0 }}>
        <div style={{
          width: 32, height: 32, borderRadius: 9, flexShrink: 0,
          background: "linear-gradient(135deg, var(--accent), var(--accent2))",
          display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "0 4px 12px var(--glow)", cursor: "pointer"
        }} onClick={onToggle}>
          <Icon name="brain" size={16} color="#fff"/>
        </div>
        {!collapsed && <span style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: 13, whiteSpace: "nowrap" }}>WHAT</span>}
      </div>
      <nav style={{ flex: 1, padding: "12px 10px", overflowY: "auto", WebkitOverflowScrolling: "touch" }}>
        {navItems.map(item => {
          const active = page === item.id;
          return (
            <div key={item.id} onClick={() => onNav(item.id)} style={{
              display: "flex", alignItems: "center", gap: 10,
              padding: collapsed ? "10px 16px" : "9px 12px",
              borderRadius: 9, marginBottom: 2, cursor: "pointer",
              background: active ? "rgba(108,99,255,0.15)" : "transparent",
              borderLeft: active ? "2px solid var(--accent)" : "2px solid transparent",
              transition: "all 0.15s", whiteSpace: "nowrap",
              justifyContent: collapsed ? "center" : "flex-start",
              WebkitTapHighlightColor: "transparent",
              touchAction: "manipulation",
            }}>
              <Icon name={item.icon} size={17} color={active ? "var(--accent)" : "var(--text3)"}/>
              {!collapsed && <span style={{ fontSize: 13, color: active ? "var(--text)" : "var(--text2)", fontWeight: active ? 500 : 400 }}>{item.label}</span>}
            </div>
          );
        })}
      </nav>
      <div style={{ padding: "12px 10px", borderTop: "1px solid var(--border)", flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 10px", borderRadius: 9, cursor: "pointer" }} onClick={() => onNav("landing")}>
          <div style={{ width: 28, height: 28, borderRadius: "50%", background: "linear-gradient(135deg, var(--accent), var(--accent2))", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, flexShrink: 0 }}>JD</div>
          {!collapsed && (
            <div style={{ flex: 1, overflow: "hidden" }}>
              <div style={{ fontSize: 12, fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>John Doe</div>
              <div style={{ fontSize: 11, color: "var(--text3)" }}>Pro Plan</div>
            </div>
          )}
          {!collapsed && <Icon name="logout" size={14} color="var(--text3)"/>}
        </div>
      </div>
    </aside>
  );
};

// ─── TOPBAR ───────────────────────────────────────────────────────────────────
const Topbar = ({ title, subtitle }) => (
  <div style={{ padding: "16px 24px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "space-between", background: "var(--bg2)", flexShrink: 0 }}>
    <div>
      <h2 style={{ fontSize: 18, fontWeight: 700, letterSpacing: "-0.5px" }}>{title}</h2>
      {subtitle && <p style={{ fontSize: 13, color: "var(--text3)", marginTop: 2 }}>{subtitle}</p>}
    </div>
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      <div style={{ position: "relative" }} className="hide-mobile">
        <input placeholder="Search anything..." style={{ width: 200, paddingLeft: 34, height: 36, fontSize: 14 }}/>
        <div style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)" }}>
          <Icon name="search" size={14} color="var(--text3)"/>
        </div>
      </div>
      <button className="btn btn-ghost" style={{ padding: "7px 10px", position: "relative", minWidth: 38, minHeight: 38 }}>
        <Icon name="bell" size={16}/>
        <span style={{ position: "absolute", top: 6, right: 6, width: 7, height: 7, borderRadius: "50%", background: "var(--accent3)", border: "2px solid var(--bg2)" }}/>
      </button>
      <button className="btn btn-primary" style={{ padding: "7px 14px", fontSize: 13, minHeight: 38 }}>
        <Icon name="plus" size={14}/> New
      </button>
    </div>
  </div>
);

// ─── STAT CARD ────────────────────────────────────────────────────────────────
const StatCard = ({ label, value, change, icon, color, delay = 0 }) => (
  <div className="glass" style={{
    padding: "22px 24px", borderRadius: var_r2,
    animation: `slide-up 0.5s cubic-bezier(0.22,1,0.36,1) ${delay}s both`,
    transition: "transform 0.2s, border-color 0.2s", cursor: "default"
  }}
  onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-3px)"; e.currentTarget.style.borderColor = "var(--border2)"; }}
  onMouseLeave={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.borderColor = "var(--border)"; }}
  >
    <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 16 }}>
      <div style={{ width: 40, height: 40, borderRadius: 11, background: color + "20", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <Icon name={icon} size={18} color={color}/>
      </div>
      <span style={{ fontSize: 12, color: change > 0 ? "var(--accent2)" : "var(--accent3)", background: change > 0 ? "rgba(0,212,170,0.1)" : "rgba(255,107,107,0.1)", padding: "3px 8px", borderRadius: 100 }}>
        {change > 0 ? "↑" : "↓"} {Math.abs(change)}%
      </span>
    </div>
    <div style={{ fontSize: 26, fontWeight: 800, fontFamily: "Syne, sans-serif", letterSpacing: "-1px", marginBottom: 4 }}>{value}</div>
    <div style={{ fontSize: 13, color: "var(--text3)" }}>{label}</div>
  </div>
);

// ─── MINI CHART ───────────────────────────────────────────────────────────────
const MiniChart = ({ data, color }) => {
  const max = Math.max(...data);
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 3, height: 44 }}>
      {data.map((v, i) => (
        <div key={i} style={{
          flex: 1, borderRadius: "2px 2px 0 0",
          height: `${(v / max) * 100}%`,
          background: i === data.length - 1 ? color : color + "50",
          transition: "height 0.5s"
        }}/>
      ))}
    </div>
  );
};

// ─── DASHBOARD PAGE ───────────────────────────────────────────────────────────
const DashboardPage = ({ onNav }) => {
  const stats = [
    { label: "Total Revenue", value: "$24,820", change: 18, icon: "trending", color: "var(--accent2)", delay: 0 },
    { label: "AI Messages", value: "1.2M", change: 34, icon: "message", color: "var(--accent)", delay: 0.05 },
    { label: "Active Workflows", value: "47", change: 12, icon: "workflow", color: "#a78bfa", delay: 0.1 },
    { label: "Team Members", value: "8", change: 25, icon: "users", color: "var(--accent4)", delay: 0.15 },
  ];

  const activities = [
    { icon: "🤖", text: "Marketing AI generated 12 email campaigns", time: "2m ago", color: "var(--accent)" },
    { icon: "💰", text: "Sales AI closed deal with TechCorp — $4,200", time: "15m ago", color: "var(--accent2)" },
    { icon: "⚡", text: "Workflow 'Lead Nurture' ran 234 times today", time: "1h ago", color: "#a78bfa" },
    { icon: "📄", text: "Research AI analyzed Q3 report PDF", time: "2h ago", color: "var(--accent4)" },
    { icon: "👥", text: "Sarah Chen joined your workspace", time: "3h ago", color: "var(--accent3)" },
  ];

  const agents = [
    { name: "Marketing AI", emoji: "📣", usage: 89, color: "var(--accent)" },
    { name: "Sales AI", emoji: "💰", usage: 72, color: "var(--accent2)" },
    { name: "Research AI", emoji: "🔬", usage: 54, color: "var(--accent4)" },
    { name: "Support AI", emoji: "💬", usage: 38, color: "var(--accent3)" },
  ];

  return (
    <div style={{ padding: "24px 28px", overflowY: "auto", flex: 1 }}>
      {/* Stats */}
      <div className="grid-4" style={{ marginBottom: 24 }}>
        {stats.map(s => <StatCard key={s.label} {...s}/>)}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 20, marginBottom: 20 }}>
        {/* Chart */}
        <div className="glass" style={{ padding: 24, borderRadius: var_r2 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
            <div>
              <h3 style={{ fontSize: 15, fontWeight: 700 }}>Revenue Overview</h3>
              <p style={{ fontSize: 12, color: "var(--text3)", marginTop: 2 }}>Last 12 months</p>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              {["1M","3M","1Y"].map((t, i) => (
                <button key={t} className="btn btn-ghost" style={{ padding: "4px 10px", fontSize: 12, background: i === 2 ? "rgba(108,99,255,0.15)" : "", color: i === 2 ? "var(--accent)" : "" }}>{t}</button>
              ))}
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "flex-end", gap: 8, height: 160 }}>
            {[35,55,40,70,50,85,65,90,75,95,80,100].map((h, i) => (
              <div key={i} style={{ flex: 1, position: "relative", height: "100%", display: "flex", alignItems: "flex-end" }}>
                <div style={{
                  width: "100%", height: `${h}%`, borderRadius: "4px 4px 0 0",
                  background: i === 11 ? "linear-gradient(to top, var(--accent), var(--accent2))" : "linear-gradient(to top, rgba(108,99,255,0.4), rgba(108,99,255,0.1))",
                  transition: "height 0.5s", cursor: "pointer"
                }}/>
                <div style={{ position: "absolute", bottom: -20, left: "50%", transform: "translateX(-50%)", fontSize: 9, color: "var(--text3)", whiteSpace: "nowrap" }}>
                  {["J","F","M","A","M","J","J","A","S","O","N","D"][i]}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Agent Usage */}
        <div className="glass" style={{ padding: 24, borderRadius: var_r2 }}>
          <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 20 }}>Agent Activity</h3>
          {agents.map(a => (
            <div key={a.name} style={{ marginBottom: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                <span style={{ fontSize: 13, display: "flex", gap: 6, alignItems: "center" }}>
                  <span>{a.emoji}</span> {a.name}
                </span>
                <span style={{ fontSize: 12, color: "var(--text3)" }}>{a.usage}%</span>
              </div>
              <div style={{ height: 6, background: "var(--surface2)", borderRadius: 3, overflow: "hidden" }}>
                <div style={{
                  height: "100%", width: `${a.usage}%`, borderRadius: 3,
                  background: a.color,
                  transition: "width 1s cubic-bezier(0.22,1,0.36,1)",
                  boxShadow: `0 0 8px ${a.color}60`
                }}/>
              </div>
            </div>
          ))}
          <button className="btn btn-ghost" style={{ width: "100%", justifyContent: "center", marginTop: 8, fontSize: 13 }} onClick={() => onNav("agents")}>
            Manage Agents <Icon name="arrow" size={13}/>
          </button>
        </div>
      </div>

      {/* Activity + Quick Actions */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 300px", gap: 20 }}>
        <div className="glass" style={{ padding: 24, borderRadius: var_r2 }}>
          <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 20 }}>Recent Activity</h3>
          {activities.map((a, i) => (
            <div key={i} style={{ display: "flex", gap: 14, marginBottom: 16, alignItems: "flex-start" }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: "var(--surface2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>{a.icon}</div>
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: 13, lineHeight: 1.5 }}>{a.text}</p>
                <span style={{ fontSize: 11, color: "var(--text3)" }}>{a.time}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="glass" style={{ padding: 24, borderRadius: var_r2 }}>
          <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>Quick Actions</h3>
          {[
            { label: "New AI Chat", icon: "message", color: "var(--accent)", nav: "chat" },
            { label: "Create Workflow", icon: "workflow", color: "#a78bfa", nav: "workflows" },
            { label: "Upload File", icon: "upload", color: "var(--accent2)", nav: "files" },
            { label: "Add Contact", icon: "users", color: "var(--accent4)", nav: "crm" },
          ].map(a => (
            <button key={a.label} className="btn btn-ghost" style={{ width: "100%", justifyContent: "flex-start", marginBottom: 8, gap: 10 }} onClick={() => onNav(a.nav)}>
              <Icon name={a.icon} size={15} color={a.color}/> {a.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

// ─── AGENTS PAGE ──────────────────────────────────────────────────────────────
const AgentsPage = ({ onNav }) => {
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [activeModel, setActiveModel] = useState("claude");
  const [fusionMode, setFusionMode] = useState(false);
  const [fusionSlots, setFusionSlots] = useState([null, null]);
  const [fusionResult, setFusionResult] = useState(null);
  const [fusing, setFusing] = useState(false);
  const [thinkingActive, setThinkingActive] = useState(false);
  const [draggedAgent, setDraggedAgent] = useState(null);
  const [evolutionLevel, setEvolutionLevel] = useState({});
  const [voiceActive, setVoiceActive] = useState(false);

  const agents = [
    { id: 1, name: "Marketing AI", emoji: "📣", color: "#6c63ff", model: "Claude Sonnet", status: "active", messages: 1240, desc: "Creates compelling marketing campaigns, ad copy, and growth strategies.", capabilities: ["Email campaigns", "Ad copywriting", "Brand voice", "A/B testing", "Market analysis"], dna: "MKT", power: 87 },
    { id: 2, name: "Sales AI", emoji: "💰", color: "#00d4aa", model: "GPT-4o", status: "active", messages: 890, desc: "Automates outreach, handles objections, and manages your sales pipeline.", capabilities: ["Cold outreach", "Follow-up sequences", "Objection handling", "Deal analysis", "CRM updates"], dna: "SLS", power: 92 },
    { id: 3, name: "Research AI", emoji: "🔬", color: "#f5a623", model: "Gemini Pro", status: "active", messages: 567, desc: "Deep research, competitive analysis, and comprehensive reports.", capabilities: ["Web research", "PDF analysis", "Competitor intel", "Market reports", "Data extraction"], dna: "RSH", power: 78 },
    { id: 4, name: "Support AI", emoji: "💬", color: "#ff6b6b", model: "Claude Haiku", status: "idle", messages: 2100, desc: "24/7 customer support with empathy and accuracy.", capabilities: ["Ticket routing", "FAQ answers", "Escalation logic", "Sentiment detection", "Multilingual"], dna: "SUP", power: 71 },
    { id: 5, name: "Social AI", emoji: "📱", color: "#a78bfa", model: "GPT-4o", status: "active", messages: 450, desc: "Viral-worthy social media content across all platforms.", capabilities: ["Post generation", "Caption writing", "Hashtag research", "Trend analysis", "Scheduling"], dna: "SOC", power: 83 },
    { id: 6, name: "Copy AI", emoji: "✍️", color: "#34d399", model: "Claude Sonnet", status: "idle", messages: 780, desc: "Long-form content, SEO blog posts, and persuasive copy.", capabilities: ["Blog writing", "SEO optimization", "Landing pages", "Email sequences", "Script writing"], dna: "CPY", power: 80 },
  ];

  // ── FUSION ENGINE ──
  const handleFuse = () => {
    if (!fusionSlots[0] || !fusionSlots[1]) return;
    setFusing(true);
    setTimeout(() => {
      const a = fusionSlots[0];
      const b = fusionSlots[1];
      setFusionResult({
        name: `${a.dna}×${b.dna} Hybrid`,
        emoji: "⚡",
        color: "#ffd700",
        parents: [a.name, b.name],
        capabilities: [...new Set([...a.capabilities.slice(0, 3), ...b.capabilities.slice(0, 3)])],
        power: Math.min(99, Math.round((a.power + b.power) / 2 + 8)),
        synergy: Math.floor(Math.random() * 30 + 70),
      });
      setFusing(false);
    }, 2400);
  };

  const resetFusion = () => {
    setFusionSlots([null, null]);
    setFusionResult(null);
  };

  // ── EVOLVE AGENT ──
  const evolveAgent = (id) => {
    setEvolutionLevel(prev => ({ ...prev, [id]: (prev[id] || 0) + 1 }));
  };

  // ── FUSION MODE VIEW ──
  if (fusionMode) {
    return (
      <div style={{ padding: "24px 28px", overflowY: "auto", flex: 1, background: "radial-gradient(ellipse at top, rgba(108,99,255,0.08), transparent 60%)" }}>
        <button className="btn btn-ghost" style={{ marginBottom: 20, fontSize: 13 }} onClick={() => { setFusionMode(false); resetFusion(); }}>
          ← Exit Fusion Lab
        </button>

        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
            <span style={{ width: 8, height: 8, borderRadius: "50%", background: "#ffd700", animation: "pulse-glow 2s ease-in-out infinite", boxShadow: "0 0 20px #ffd700" }}/>
            <span className="tag" style={{ background: "rgba(255,215,0,0.1)", color: "#ffd700", border: "1px solid rgba(255,215,0,0.3)" }}>EXPERIMENTAL</span>
          </div>
          <h2 style={{ fontSize: 32, fontWeight: 800, fontFamily: "Syne, sans-serif", letterSpacing: "-1px", marginBottom: 8 }}>
            ⚡ Agent Fusion Lab
          </h2>
          <p style={{ fontSize: 14, color: "var(--text2)" }}>Combine two agents to forge a hybrid super-intelligence with merged capabilities.</p>
        </div>

        {/* Fusion Chamber */}
        <div className="glass2" style={{
          padding: "40px 32px", borderRadius: var_r2, marginBottom: 24,
          background: fusing ? "linear-gradient(135deg, rgba(108,99,255,0.15), rgba(255,215,0,0.1))" : "var(--surface2)",
          transition: "background 0.5s",
          position: "relative", overflow: "hidden",
        }}>
          {/* Animated energy lines during fusion */}
          {fusing && (
            <div style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
              {[...Array(12)].map((_, i) => (
                <div key={i} style={{
                  position: "absolute", top: "50%", left: "50%",
                  width: 200, height: 1,
                  background: "linear-gradient(90deg, transparent, #ffd700, transparent)",
                  transformOrigin: "0 50%",
                  transform: `rotate(${i * 30}deg)`,
                  animation: `pulse-glow 0.4s ease-in-out infinite ${i * 0.05}s`,
                }}/>
              ))}
            </div>
          )}

          <div style={{ display: "grid", gridTemplateColumns: "1fr auto 1fr", gap: 24, alignItems: "center", position: "relative" }}>
            {/* Slot 1 */}
            <FusionSlot
              agent={fusionSlots[0]}
              onClear={() => setFusionSlots([null, fusionSlots[1]])}
              onDrop={(agent) => setFusionSlots([agent, fusionSlots[1]])}
              draggedAgent={draggedAgent}
              label="GENESIS"
            />

            {/* Center fusion icon */}
            <div style={{
              width: 64, height: 64, borderRadius: "50%",
              background: fusing ? "radial-gradient(circle, #ffd700, #ff6b6b)" : "var(--surface2)",
              border: "2px solid " + (fusing ? "#ffd700" : "var(--border2)"),
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 28,
              animation: fusing ? "spin-slow 1s linear infinite, pulse-glow 1.5s ease-in-out infinite" : "none",
              boxShadow: fusing ? "0 0 60px #ffd700" : "none",
            }}>
              {fusing ? "✨" : "⚡"}
            </div>

            {/* Slot 2 */}
            <FusionSlot
              agent={fusionSlots[1]}
              onClear={() => setFusionSlots([fusionSlots[0], null])}
              onDrop={(agent) => setFusionSlots([fusionSlots[0], agent])}
              draggedAgent={draggedAgent}
              label="CATALYST"
            />
          </div>

          {/* Fuse button or result */}
          {!fusionResult && (
            <div style={{ display: "flex", justifyContent: "center", marginTop: 32 }}>
              <button
                className="btn"
                style={{
                  fontSize: 14, padding: "12px 32px",
                  background: (fusionSlots[0] && fusionSlots[1]) ? "linear-gradient(135deg, #ffd700, #ff6b6b)" : "var(--surface)",
                  color: (fusionSlots[0] && fusionSlots[1]) ? "#000" : "var(--text3)",
                  fontWeight: 700,
                  cursor: (fusionSlots[0] && fusionSlots[1]) ? "pointer" : "not-allowed",
                  boxShadow: (fusionSlots[0] && fusionSlots[1]) ? "0 0 40px rgba(255,215,0,0.4)" : "none",
                }}
                onClick={handleFuse}
                disabled={!fusionSlots[0] || !fusionSlots[1] || fusing}
              >
                {fusing ? "⚛ Fusing..." : "⚡ Initiate Fusion"}
              </button>
            </div>
          )}

          {fusionResult && (
            <div style={{
              marginTop: 32, padding: 24, borderRadius: 16,
              background: "linear-gradient(135deg, rgba(255,215,0,0.1), rgba(255,107,107,0.05))",
              border: "1px solid rgba(255,215,0,0.3)",
              animation: "slide-up 0.6s cubic-bezier(0.22,1,0.36,1) both",
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 16 }}>
                <div style={{
                  width: 56, height: 56, borderRadius: 16,
                  background: "linear-gradient(135deg, #ffd700, #ff6b6b)",
                  display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28,
                  boxShadow: "0 0 30px rgba(255,215,0,0.4)",
                }}>⚡</div>
                <div style={{ flex: 1 }}>
                  <h3 style={{ fontSize: 20, fontWeight: 800, fontFamily: "Syne, sans-serif", letterSpacing: "-0.5px" }}>{fusionResult.name}</h3>
                  <p style={{ fontSize: 12, color: "var(--text3)", marginTop: 2 }}>Born from: {fusionResult.parents.join(" + ")}</p>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 32, fontWeight: 800, fontFamily: "Syne, sans-serif", color: "#ffd700" }}>{fusionResult.power}</div>
                  <div style={{ fontSize: 10, color: "var(--text3)", textTransform: "uppercase", letterSpacing: "1px" }}>Power Level</div>
                </div>
              </div>

              {/* Synergy meter */}
              <div style={{ marginBottom: 16 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, fontSize: 12 }}>
                  <span style={{ color: "var(--text2)" }}>Synergy</span>
                  <span style={{ color: "#ffd700", fontWeight: 600 }}>{fusionResult.synergy}%</span>
                </div>
                <div style={{ height: 6, background: "var(--surface2)", borderRadius: 3, overflow: "hidden" }}>
                  <div style={{
                    height: "100%", width: `${fusionResult.synergy}%`,
                    background: "linear-gradient(90deg, #ffd700, #ff6b6b)",
                    boxShadow: "0 0 10px #ffd700",
                    animation: "slide-up 1s cubic-bezier(0.22,1,0.36,1) both",
                  }}/>
                </div>
              </div>

              {/* Combined capabilities */}
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 16 }}>
                {fusionResult.capabilities.map(c => (
                  <span key={c} className="tag" style={{ background: "rgba(255,215,0,0.1)", color: "#ffd700", border: "1px solid rgba(255,215,0,0.3)" }}>
                    ✦ {c}
                  </span>
                ))}
              </div>

              <div style={{ display: "flex", gap: 10 }}>
                <button className="btn btn-primary" style={{ fontSize: 13, background: "linear-gradient(135deg, #ffd700, #ff6b6b)", color: "#000" }}>
                  Deploy Hybrid Agent
                </button>
                <button className="btn btn-ghost" style={{ fontSize: 13 }} onClick={resetFusion}>
                  Try Another Fusion
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Available agents to drag */}
        <div>
          <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 12, color: "var(--text2)", textTransform: "uppercase", letterSpacing: "1px" }}>
            Drag Agents Into Chamber
          </h3>
          <div className="grid-3" style={{ gap: 12 }}>
            {agents.map(a => (
              <div key={a.id}
                draggable
                onDragStart={() => setDraggedAgent(a)}
                onDragEnd={() => setDraggedAgent(null)}
                onClick={() => {
                  if (!fusionSlots[0]) setFusionSlots([a, fusionSlots[1]]);
                  else if (!fusionSlots[1]) setFusionSlots([fusionSlots[0], a]);
                }}
                style={{
                  padding: "12px 14px", borderRadius: 12, cursor: "grab",
                  background: "var(--surface)", border: `1px solid ${a.color}30`,
                  display: "flex", alignItems: "center", gap: 12,
                  transition: "all 0.2s",
                  opacity: (fusionSlots[0]?.id === a.id || fusionSlots[1]?.id === a.id) ? 0.4 : 1,
                }}
                onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.borderColor = a.color; }}
                onMouseLeave={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.borderColor = a.color + "30"; }}
              >
                <div style={{ width: 36, height: 36, borderRadius: 10, background: a.color + "20", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>{a.emoji}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{a.name}</div>
                  <div style={{ fontSize: 10, color: "var(--text3)", fontFamily: "monospace" }}>DNA: {a.dna} · PWR {a.power}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ── AGENT DETAIL VIEW ──
  if (selectedAgent) {
    const a = agents.find(ag => ag.id === selectedAgent);
    const evolved = evolutionLevel[a.id] || 0;
    return (
      <div style={{ padding: "24px 28px", overflowY: "auto", flex: 1 }}>
        <button className="btn btn-ghost" style={{ marginBottom: 20, fontSize: 13 }} onClick={() => setSelectedAgent(null)}>
          ← Back to Agents
        </button>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 20 }}>
          <div>
            <div className="glass" style={{ padding: 28, borderRadius: var_r2, marginBottom: 20 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 20 }}>
                <div style={{
                  width: 56, height: 56, borderRadius: 16,
                  background: a.color + "20",
                  display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26,
                  position: "relative",
                }}>
                  {a.emoji}
                  {evolved > 0 && (
                    <div style={{
                      position: "absolute", top: -6, right: -6,
                      background: "linear-gradient(135deg, #ffd700, #ff6b6b)",
                      color: "#000", fontSize: 10, fontWeight: 800,
                      padding: "2px 6px", borderRadius: 100,
                      boxShadow: "0 0 12px rgba(255,215,0,0.6)",
                    }}>★{evolved}</div>
                  )}
                </div>
                <div>
                  <h2 style={{ fontSize: 20, fontWeight: 700 }}>{a.name}</h2>
                  <span style={{ fontSize: 12, color: "var(--text3)" }}>Powered by {a.model} · DNA: {a.dna}</span>
                </div>
                <button className="btn btn-primary" style={{ marginLeft: "auto" }} onClick={() => onNav("chat")}>
                  <Icon name="message" size={14}/> Chat with Agent
                </button>
              </div>
              <p style={{ fontSize: 14, color: "var(--text2)", lineHeight: 1.7, marginBottom: 24 }}>{a.desc}</p>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 12 }}>Capabilities</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                  {a.capabilities.map(c => (
                    <span key={c} className="tag" style={{ background: a.color + "15", color: a.color, border: `1px solid ${a.color}30` }}>{c}</span>
                  ))}
                </div>
              </div>
            </div>

            {/* 🧠 NEURAL THINKING VISUALIZER */}
            <div className="glass" style={{ padding: 24, borderRadius: var_r2, marginBottom: 20, position: "relative", overflow: "hidden" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <h3 style={{ fontSize: 15, fontWeight: 700 }}>Neural Activity</h3>
                    <span className="tag" style={{ fontSize: 9, background: thinkingActive ? "rgba(0,212,170,0.15)" : "rgba(255,255,255,0.05)", color: thinkingActive ? "var(--accent2)" : "var(--text3)" }}>
                      <span style={{ width: 5, height: 5, borderRadius: "50%", background: thinkingActive ? "var(--accent2)" : "var(--text3)", animation: thinkingActive ? "pulse-glow 1s ease-in-out infinite" : "none" }}/>
                      {thinkingActive ? "PROCESSING" : "STANDBY"}
                    </span>
                  </div>
                  <p style={{ fontSize: 12, color: "var(--text3)", marginTop: 2 }}>Watch the agent's mind in real-time</p>
                </div>
                <button className="btn btn-ghost" style={{ fontSize: 12 }} onClick={() => setThinkingActive(!thinkingActive)}>
                  {thinkingActive ? "Stop" : "▶ Activate"}
                </button>
              </div>
              <NeuralVisualizer color={a.color} active={thinkingActive} capabilities={a.capabilities}/>
            </div>

            <div className="glass" style={{ padding: 24, borderRadius: var_r2 }}>
              <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>System Prompt</h3>
              <textarea style={{ height: 160, resize: "vertical", fontSize: 13, lineHeight: 1.6 }}
                defaultValue={`You are ${a.name}, an expert AI assistant specialized in ${a.capabilities[0].toLowerCase()} and ${a.capabilities[1].toLowerCase()}. Be concise, professional, and results-driven. Always provide actionable insights.`}
              />
              <div style={{ display: "flex", gap: 10, marginTop: 12 }}>
                <button className="btn btn-primary" style={{ fontSize: 13 }}>Save Prompt</button>
                <button className="btn btn-ghost" style={{ fontSize: 13 }}>Reset to Default</button>
              </div>
            </div>
          </div>
          <div>
            {/* 🎯 POWER LEVEL */}
            <div className="glass" style={{ padding: 20, borderRadius: var_r2, marginBottom: 16, position: "relative", overflow: "hidden" }}>
              <div style={{ position: "absolute", top: 0, right: 0, width: 80, height: 80, background: `radial-gradient(circle, ${a.color}30, transparent 70%)`, filter: "blur(20px)" }}/>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                <h3 style={{ fontSize: 13, fontWeight: 700, textTransform: "uppercase", letterSpacing: "1px", color: "var(--text2)" }}>Power Level</h3>
                <span style={{ fontSize: 10, color: "var(--text3)", fontFamily: "monospace" }}>{a.dna}-{String(a.id).padStart(3, "0")}</span>
              </div>
              <div style={{ fontSize: 56, fontWeight: 800, fontFamily: "Syne, sans-serif", letterSpacing: "-2px", lineHeight: 1, marginBottom: 4, background: `linear-gradient(135deg, ${a.color}, #fff)`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                {Math.min(99, a.power + evolved * 3)}
              </div>
              <div style={{ height: 4, background: "var(--surface2)", borderRadius: 2, overflow: "hidden", marginBottom: 16 }}>
                <div style={{ height: "100%", width: `${Math.min(99, a.power + evolved * 3)}%`, background: `linear-gradient(90deg, ${a.color}, #fff)`, boxShadow: `0 0 12px ${a.color}` }}/>
              </div>
              <button
                className="btn"
                style={{
                  width: "100%", justifyContent: "center", fontSize: 12,
                  background: `linear-gradient(135deg, ${a.color}, #ffd700)`,
                  color: "#000", fontWeight: 700,
                }}
                onClick={() => evolveAgent(a.id)}
              >
                ⬆ Evolve Agent (+3 PWR)
              </button>
            </div>

            {/* 🎙️ VOICE CLONE */}
            <div className="glass" style={{ padding: 20, borderRadius: var_r2, marginBottom: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                <h3 style={{ fontSize: 13, fontWeight: 700, textTransform: "uppercase", letterSpacing: "1px", color: "var(--text2)" }}>Voice Clone</h3>
                <span className="tag" style={{ fontSize: 9, background: "rgba(167,139,250,0.15)", color: "#a78bfa" }}>BETA</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: "16px 0" }}>
                <button
                  onClick={() => setVoiceActive(!voiceActive)}
                  style={{
                    width: 80, height: 80, borderRadius: "50%",
                    background: voiceActive ? `radial-gradient(circle, ${a.color}, ${a.color}80)` : "var(--surface2)",
                    border: `2px solid ${voiceActive ? a.color : "var(--border)"}`,
                    cursor: "pointer", transition: "all 0.3s",
                    boxShadow: voiceActive ? `0 0 40px ${a.color}80` : "none",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    animation: voiceActive ? "pulse-glow 1.5s ease-in-out infinite" : "none",
                  }}
                >
                  <Icon name="mic" size={28} color={voiceActive ? "#fff" : "var(--text3)"}/>
                </button>
              </div>
              <p style={{ fontSize: 11, color: "var(--text3)", textAlign: "center", lineHeight: 1.5 }}>
                {voiceActive ? "🎙 Recording voice sample..." : "Tap to clone your voice for this agent"}
              </p>
              {voiceActive && (
                <div style={{ display: "flex", justifyContent: "center", gap: 3, marginTop: 12 }}>
                  {[...Array(20)].map((_, i) => (
                    <div key={i} style={{
                      width: 2, background: a.color, borderRadius: 1,
                      height: 8 + Math.random() * 24,
                      animation: `pulse-glow ${0.4 + Math.random() * 0.6}s ease-in-out ${i * 0.05}s infinite`,
                    }}/>
                  ))}
                </div>
              )}
            </div>

            <div className="glass" style={{ padding: 20, borderRadius: var_r2, marginBottom: 16 }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, marginBottom: 16 }}>Model Settings</h3>
              {["claude", "gpt4", "gemini"].map(m => (
                <div key={m} onClick={() => setActiveModel(m)} style={{
                  padding: "10px 14px", borderRadius: 10, marginBottom: 8, cursor: "pointer",
                  background: activeModel === m ? "rgba(108,99,255,0.15)" : "transparent",
                  border: `1px solid ${activeModel === m ? "rgba(108,99,255,0.3)" : "var(--border)"}`,
                  display: "flex", alignItems: "center", gap: 10
                }}>
                  <span style={{ fontSize: 16 }}>{m === "claude" ? "🟣" : m === "gpt4" ? "🟢" : "🔵"}</span>
                  <span style={{ fontSize: 13 }}>{m === "claude" ? "Claude Sonnet" : m === "gpt4" ? "GPT-4o" : "Gemini Pro"}</span>
                  {activeModel === m && <Icon name="check" size={14} color="var(--accent)" style={{ marginLeft: "auto" }}/>}
                </div>
              ))}
            </div>
            <div className="glass" style={{ padding: 20, borderRadius: var_r2 }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, marginBottom: 16 }}>Stats</h3>
              {[["Total Messages", a.messages.toLocaleString()], ["Avg Response", "1.2s"], ["Accuracy", "94%"], ["Evolution", `Level ${evolved}`]].map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
                  <span style={{ fontSize: 13, color: "var(--text2)" }}>{k}</span>
                  <span style={{ fontSize: 13, fontWeight: 600 }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ── AGENTS LIST ──
  return (
    <div style={{ padding: "24px 28px", overflowY: "auto", flex: 1 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24, flexWrap: "wrap", gap: 12 }}>
        <div>
          <h3 style={{ fontSize: 16, fontWeight: 700 }}>Your AI Agents</h3>
          <p style={{ fontSize: 13, color: "var(--text3)", marginTop: 2 }}>Deploy specialized agents for every business function</p>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <button
            className="btn"
            style={{
              fontSize: 13, padding: "10px 18px",
              background: "linear-gradient(135deg, #ffd700, #ff6b6b)",
              color: "#000", fontWeight: 700,
              boxShadow: "0 0 24px rgba(255,215,0,0.3)",
              animation: "pulse-glow 3s ease-in-out infinite",
            }}
            onClick={() => setFusionMode(true)}
          >
            ⚡ Fusion Lab
          </button>
          <button className="btn btn-primary" style={{ fontSize: 13 }}><Icon name="plus" size={14}/> New Agent</button>
        </div>
      </div>
      <div className="grid-3" style={{ gap: 16 }}>
        {agents.map((a, i) => {
          const evolved = evolutionLevel[a.id] || 0;
          return (
            <div key={a.id} className="glass" style={{
              padding: 22, borderRadius: var_r2, cursor: "pointer",
              animation: `slide-up 0.5s cubic-bezier(0.22,1,0.36,1) ${i * 0.07}s both`,
              transition: "all 0.2s",
              position: "relative", overflow: "hidden",
            }}
            onClick={() => setSelectedAgent(a.id)}
            onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.borderColor = a.color; e.currentTarget.style.boxShadow = `0 12px 40px ${a.color}30`; }}
            onMouseLeave={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.borderColor = "var(--border)"; e.currentTarget.style.boxShadow = "none"; }}
            >
              {/* Animated corner glow */}
              <div style={{ position: "absolute", top: -20, right: -20, width: 80, height: 80, background: `radial-gradient(circle, ${a.color}30, transparent 70%)`, filter: "blur(20px)", pointerEvents: "none" }}/>

              <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 16, position: "relative" }}>
                <div style={{ width: 48, height: 48, borderRadius: 14, background: a.color + "20", border: `1px solid ${a.color}30`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, position: "relative" }}>
                  {a.emoji}
                  {evolved > 0 && (
                    <div style={{
                      position: "absolute", top: -4, right: -4,
                      background: "linear-gradient(135deg, #ffd700, #ff6b6b)",
                      color: "#000", fontSize: 9, fontWeight: 800,
                      padding: "1px 5px", borderRadius: 100,
                      boxShadow: "0 0 8px rgba(255,215,0,0.6)",
                    }}>★{evolved}</div>
                  )}
                </div>
                <span className="tag" style={{ fontSize: 11, background: a.status === "active" ? "rgba(0,212,170,0.1)" : "rgba(255,255,255,0.05)", color: a.status === "active" ? "var(--accent2)" : "var(--text3)" }}>
                  <span style={{ width: 5, height: 5, borderRadius: "50%", background: a.status === "active" ? "var(--accent2)" : "var(--text3)", display: "inline-block" }}/>
                  {a.status}
                </span>
              </div>
              <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 6 }}>{a.name}</h3>
              <p style={{ fontSize: 13, color: "var(--text2)", lineHeight: 1.5, marginBottom: 14, minHeight: 40 }}>{a.desc}</p>

              {/* Power bar */}
              <div style={{ marginBottom: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: "var(--text3)", marginBottom: 4, fontFamily: "monospace", textTransform: "uppercase", letterSpacing: "1px" }}>
                  <span>PWR</span><span>{Math.min(99, a.power + evolved * 3)}</span>
                </div>
                <div style={{ height: 3, background: "var(--surface2)", borderRadius: 2, overflow: "hidden" }}>
                  <div style={{ height: "100%", width: `${Math.min(99, a.power + evolved * 3)}%`, background: `linear-gradient(90deg, ${a.color}, #fff)`, boxShadow: `0 0 6px ${a.color}80` }}/>
                </div>
              </div>

              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ fontSize: 12, color: "var(--text3)" }}>{a.messages.toLocaleString()} msgs</span>
                <span className="tag" style={{ fontSize: 11, background: "var(--surface2)", color: "var(--text2)", fontFamily: "monospace" }}>{a.dna}</span>
              </div>
            </div>
          );
        })}
        {/* Fusion Lab Card */}
        <div onClick={() => setFusionMode(true)} style={{
          padding: 22, borderRadius: var_r2, cursor: "pointer",
          background: "linear-gradient(135deg, rgba(255,215,0,0.08), rgba(255,107,107,0.05))",
          border: "1px dashed rgba(255,215,0,0.4)",
          display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 12,
          minHeight: 180, transition: "all 0.2s",
          position: "relative", overflow: "hidden",
        }}
        onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.borderColor = "#ffd700"; e.currentTarget.style.boxShadow = "0 12px 40px rgba(255,215,0,0.2)"; }}
        onMouseLeave={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.borderColor = "rgba(255,215,0,0.4)"; e.currentTarget.style.boxShadow = "none"; }}
        >
          <div style={{ position: "absolute", inset: 0, background: "radial-gradient(circle at center, rgba(255,215,0,0.15), transparent 70%)", pointerEvents: "none" }}/>
          <div style={{
            width: 56, height: 56, borderRadius: "50%",
            background: "radial-gradient(circle, #ffd700, #ff6b6b)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 28, boxShadow: "0 0 30px rgba(255,215,0,0.4)",
            animation: "pulse-glow 2s ease-in-out infinite",
          }}>⚡</div>
          <div style={{ textAlign: "center", position: "relative" }}>
            <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 4, color: "#ffd700" }}>Agent Fusion Lab</div>
            <div style={{ fontSize: 11, color: "var(--text3)" }}>Combine 2 agents → 1 super-agent</div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── FUSION SLOT ──────────────────────────────────────────────────────────────
const FusionSlot = ({ agent, onClear, onDrop, draggedAgent, label }) => {
  const [over, setOver] = useState(false);
  return (
    <div
      onDragOver={e => { e.preventDefault(); setOver(true); }}
      onDragLeave={() => setOver(false)}
      onDrop={() => { setOver(false); if (draggedAgent) onDrop(draggedAgent); }}
      style={{
        padding: 24, minHeight: 140, borderRadius: 16,
        background: agent ? agent.color + "15" : "var(--surface)",
        border: `2px ${agent ? "solid" : "dashed"} ${agent ? agent.color : (over ? "#ffd700" : "var(--border)")}`,
        display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
        transition: "all 0.3s",
        boxShadow: agent ? `0 0 40px ${agent.color}40` : (over ? "0 0 30px rgba(255,215,0,0.4)" : "none"),
        position: "relative",
      }}
    >
      <div style={{ position: "absolute", top: 8, left: 12, fontSize: 9, color: "var(--text3)", fontFamily: "monospace", letterSpacing: "1px" }}>{label}</div>
      {agent ? (
        <>
          <button
            onClick={onClear}
            style={{
              position: "absolute", top: 8, right: 8,
              width: 22, height: 22, borderRadius: "50%",
              background: "var(--surface2)", border: "1px solid var(--border)",
              cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
            }}
          ><Icon name="x" size={11} color="var(--text2)"/></button>
          <div style={{ fontSize: 40, marginBottom: 8 }}>{agent.emoji}</div>
          <div style={{ fontSize: 14, fontWeight: 700 }}>{agent.name}</div>
          <div style={{ fontSize: 10, color: "var(--text3)", fontFamily: "monospace", marginTop: 4 }}>{agent.dna} · PWR {agent.power}</div>
        </>
      ) : (
        <>
          <div style={{ fontSize: 32, marginBottom: 8, opacity: 0.4 }}>+</div>
          <div style={{ fontSize: 12, color: "var(--text3)" }}>Drop or click an agent</div>
        </>
      )}
    </div>
  );
};

// ─── NEURAL VISUALIZER ────────────────────────────────────────────────────────
const NeuralVisualizer = ({ color, active, capabilities }) => {
  const [pulses, setPulses] = useState([]);

  useEffect(() => {
    if (!active) { setPulses([]); return; }
    const t = setInterval(() => {
      setPulses(p => {
        const newPulse = { id: Date.now() + Math.random(), from: Math.floor(Math.random() * 5), to: 5 + Math.floor(Math.random() * 3) };
        return [...p.slice(-12), newPulse];
      });
    }, 280);
    return () => clearInterval(t);
  }, [active]);

  // Layers: input (5 nodes), hidden (8), output (3 = capabilities)
  const inputNodes = capabilities.slice(0, 5);
  const hiddenLayer = Array.from({ length: 8 });
  const outputs = ["Analysis", "Action", "Output"];

  const getPos = (layer, idx, total) => {
    const x = layer === "input" ? 40 : layer === "hidden" ? 200 : 360;
    const y = 30 + (idx * (180 / (total - 1)));
    return { x, y };
  };

  return (
    <div style={{ position: "relative", height: 240, width: "100%", background: "rgba(0,0,0,0.3)", borderRadius: 12, overflow: "hidden" }}>
      <svg viewBox="0 0 400 240" style={{ width: "100%", height: "100%" }}>
        {/* Connections from input → hidden */}
        {inputNodes.map((_, i) =>
          hiddenLayer.map((_, j) => {
            const from = getPos("input", i, inputNodes.length);
            const to = getPos("hidden", j, hiddenLayer.length);
            return (
              <line key={`ih-${i}-${j}`} x1={from.x} y1={from.y} x2={to.x} y2={to.y}
                stroke={color} strokeOpacity={active ? 0.15 : 0.05} strokeWidth="0.5"/>
            );
          })
        )}
        {/* Connections from hidden → output */}
        {hiddenLayer.map((_, i) =>
          outputs.map((_, j) => {
            const from = getPos("hidden", i, hiddenLayer.length);
            const to = getPos("output", j, outputs.length);
            return (
              <line key={`ho-${i}-${j}`} x1={from.x} y1={from.y} x2={to.x} y2={to.y}
                stroke={color} strokeOpacity={active ? 0.15 : 0.05} strokeWidth="0.5"/>
            );
          })
        )}

        {/* Animated signal pulses */}
        {pulses.map(p => {
          const from = getPos("input", p.from % inputNodes.length, inputNodes.length);
          const mid = getPos("hidden", (p.from * 2) % hiddenLayer.length, hiddenLayer.length);
          const to = getPos("output", p.to % outputs.length, outputs.length);
          return (
            <g key={p.id}>
              <circle r="3" fill={color}>
                <animateMotion dur="1.4s" path={`M${from.x},${from.y} L${mid.x},${mid.y} L${to.x},${to.y}`} fill="freeze"/>
                <animate attributeName="opacity" from="1" to="0" dur="1.4s" fill="freeze"/>
              </circle>
            </g>
          );
        })}

        {/* Input nodes */}
        {inputNodes.map((cap, i) => {
          const pos = getPos("input", i, inputNodes.length);
          return (
            <g key={`in-${i}`}>
              <circle cx={pos.x} cy={pos.y} r="6" fill={color} fillOpacity={active ? 0.6 : 0.3} stroke={color} strokeOpacity={active ? 1 : 0.5} strokeWidth="1">
                {active && <animate attributeName="r" values="6;8;6" dur="2s" repeatCount="indefinite" begin={`${i * 0.2}s`}/>}
              </circle>
              <text x={pos.x - 12} y={pos.y + 3} fontSize="8" fill="rgba(255,255,255,0.6)" textAnchor="end" fontFamily="monospace">{cap.slice(0, 12)}</text>
            </g>
          );
        })}
        {/* Hidden nodes */}
        {hiddenLayer.map((_, i) => {
          const pos = getPos("hidden", i, hiddenLayer.length);
          return (
            <circle key={`hn-${i}`} cx={pos.x} cy={pos.y} r="5" fill={color} fillOpacity={active ? 0.5 : 0.2} stroke={color} strokeOpacity={active ? 0.8 : 0.4} strokeWidth="1">
              {active && <animate attributeName="fillOpacity" values="0.5;1;0.5" dur="1.5s" repeatCount="indefinite" begin={`${i * 0.15}s`}/>}
            </circle>
          );
        })}
        {/* Output nodes */}
        {outputs.map((label, i) => {
          const pos = getPos("output", i, outputs.length);
          return (
            <g key={`on-${i}`}>
              <circle cx={pos.x} cy={pos.y} r="8" fill={color} fillOpacity={active ? 0.7 : 0.3} stroke={color} strokeOpacity={active ? 1 : 0.5} strokeWidth="1.5">
                {active && <animate attributeName="r" values="8;11;8" dur="2s" repeatCount="indefinite" begin={`${i * 0.3}s`}/>}
              </circle>
              <text x={pos.x + 14} y={pos.y + 3} fontSize="9" fill="rgba(255,255,255,0.7)" fontFamily="monospace">{label}</text>
            </g>
          );
        })}
      </svg>
      {/* Stats overlay */}
      <div style={{ position: "absolute", top: 10, right: 10, display: "flex", flexDirection: "column", gap: 4, fontFamily: "monospace", fontSize: 10, color: "var(--text3)" }}>
        <span>NODES: {inputNodes.length + hiddenLayer.length + outputs.length}</span>
        <span>SIGNALS: {active ? pulses.length : 0}</span>
        <span style={{ color: active ? "var(--accent2)" : "var(--text3)" }}>{active ? "● LIVE" : "○ IDLE"}</span>
      </div>
    </div>
  );
};

// ─── CHAT PAGE ────────────────────────────────────────────────────────────────
const ChatPage = () => {
  // ── PERSISTED API CONFIG ──
  const [apiKey, setApiKey] = useState("");
  const [provider, setProvider] = useState("anthropic"); // anthropic | openai | gemini
  const [model, setModel] = useState("claude-sonnet-4-20250514");
  const [showSettings, setShowSettings] = useState(false);

  // ── AGENT/PROMPT CUSTOMIZATION ──
  const [agents, setAgents] = useState([
    { name: "Marketing AI", emoji: "📣", systemPrompt: "You are a marketing expert. Help with campaigns, copy, and growth strategies." },
    { name: "Sales AI", emoji: "💰", systemPrompt: "You are a sales expert. Help with outreach, objection handling, and closing deals." },
    { name: "Research AI", emoji: "🔬", systemPrompt: "You are a research analyst. Provide thorough, fact-based analysis with citations." },
    { name: "Support AI", emoji: "💬", systemPrompt: "You are a customer support specialist. Be empathetic, clear, and solution-focused." },
    { name: "Custom AI", emoji: "✨", systemPrompt: "You are a helpful assistant. Answer anything the user asks." },
  ]);
  const [selectedAgentIdx, setSelectedAgentIdx] = useState(0);
  const [editingPrompt, setEditingPrompt] = useState(false);
  const [promptDraft, setPromptDraft] = useState("");

  const selectedAgent = agents[selectedAgentIdx];

  // ── MESSAGES ──
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  const abortControllerRef = useRef(null);

  // Load saved config from localStorage
  useEffect(() => {
    try {
      const savedKey = localStorage.getItem("what_api_key");
      const savedProvider = localStorage.getItem("what_provider");
      const savedModel = localStorage.getItem("what_model");
      const savedAgents = localStorage.getItem("what_agents");
      if (savedKey) setApiKey(savedKey);
      if (savedProvider) setProvider(savedProvider);
      if (savedModel) setModel(savedModel);
      if (savedAgents) setAgents(JSON.parse(savedAgents));
    } catch (e) { /* ignore */ }
  }, []);

  // Persist agents
  useEffect(() => {
    try { localStorage.setItem("what_agents", JSON.stringify(agents)); } catch(e){}
  }, [agents]);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, loading]);

  const saveSettings = () => {
    try {
      localStorage.setItem("what_api_key", apiKey);
      localStorage.setItem("what_provider", provider);
      localStorage.setItem("what_model", model);
    } catch(e){}
    setShowSettings(false);
    setError("");
  };

  const savePrompt = () => {
    const updated = [...agents];
    updated[selectedAgentIdx] = { ...updated[selectedAgentIdx], systemPrompt: promptDraft };
    setAgents(updated);
    setEditingPrompt(false);
  };

  // ── CALL AI API ──
  const callAI = async (history, sysPrompt) => {
    if (provider === "anthropic") {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-api-key": apiKey,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true",
        },
        body: JSON.stringify({
          model: model,
          max_tokens: 2048,
          system: sysPrompt,
          messages: history.map(m => ({ role: m.role, content: m.content })),
        }),
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error?.message || `Anthropic API error: ${res.status}`);
      }
      const data = await res.json();
      return data.content?.[0]?.text || "(no response)";
    }

    if (provider === "openai") {
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "authorization": `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: model,
          messages: [
            { role: "system", content: sysPrompt },
            ...history.map(m => ({ role: m.role, content: m.content })),
          ],
        }),
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error?.message || `OpenAI API error: ${res.status}`);
      }
      const data = await res.json();
      return data.choices?.[0]?.message?.content || "(no response)";
    }

    if (provider === "gemini") {
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: sysPrompt }] },
          contents: history.map(m => ({
            role: m.role === "assistant" ? "model" : "user",
            parts: [{ text: m.content }],
          })),
        }),
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error?.message || `Gemini API error: ${res.status}`);
      }
      const data = await res.json();
      return data.candidates?.[0]?.content?.parts?.[0]?.text || "(no response)";
    }

    throw new Error("Unknown provider");
  };

  const sendMessage = useCallback(async () => {
    if (!input.trim() || loading) return;

    if (!apiKey) {
      setError("⚠ Add your API key in Settings to start chatting.");
      setShowSettings(true);
      return;
    }

    const userMsg = {
      id: Date.now(),
      role: "user",
      content: input,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    };
    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setInput("");
    setLoading(true);
    setError("");

    try {
      const reply = await callAI(newHistory, selectedAgent.systemPrompt);
      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        role: "assistant",
        content: reply,
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      }]);
    } catch (e) {
      setError(e.message || "Something went wrong. Check your API key and try again.");
    }
    setLoading(false);
  }, [input, loading, messages, apiKey, provider, model, selectedAgent]);

  const renderContent = (text) => {
    return text
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
      .replace(/\*(.*?)\*/g, "<em>$1</em>")
      .replace(/`([^`]+)`/g, '<code style="background:rgba(108,99,255,0.15);padding:2px 6px;border-radius:4px;font-family:monospace;font-size:12px;color:var(--accent)">$1</code>')
      .replace(/\n/g, "<br/>");
  };

  const clearChat = () => { setMessages([]); setError(""); };

  const modelOptions = {
    anthropic: [
      { id: "claude-opus-4-5", label: "Claude Opus 4.5 (most powerful)" },
      { id: "claude-sonnet-4-20250514", label: "Claude Sonnet 4 (balanced)" },
      { id: "claude-haiku-4-5-20251001", label: "Claude Haiku 4.5 (fastest)" },
    ],
    openai: [
      { id: "gpt-4o", label: "GPT-4o" },
      { id: "gpt-4o-mini", label: "GPT-4o mini" },
      { id: "gpt-4-turbo", label: "GPT-4 Turbo" },
    ],
    gemini: [
      { id: "gemini-2.0-flash-exp", label: "Gemini 2.0 Flash" },
      { id: "gemini-1.5-pro", label: "Gemini 1.5 Pro" },
      { id: "gemini-1.5-flash", label: "Gemini 1.5 Flash" },
    ],
  };

  const providerLabel = { anthropic: "Anthropic (Claude)", openai: "OpenAI (GPT)", gemini: "Google (Gemini)" };

  return (
    <div style={{ display: "flex", flex: 1, overflow: "hidden", height: "100%" }}>
      {/* Conversations sidebar */}
      <div className="hide-mobile" style={{ width: 240, borderRight: "1px solid var(--border)", display: "flex", flexDirection: "column", background: "var(--bg2)", flexShrink: 0 }}>
        <div style={{ padding: "16px 14px", borderBottom: "1px solid var(--border)" }}>
          <button className="btn btn-primary" style={{ width: "100%", justifyContent: "center", fontSize: 13, padding: "8px 14px" }} onClick={clearChat}>
            <Icon name="plus" size={13}/> New Chat
          </button>
        </div>
        <div style={{ padding: "12px 8px", borderBottom: "1px solid var(--border)" }}>
          <div style={{ fontSize: 11, color: "var(--text3)", padding: "0 8px", marginBottom: 8, textTransform: "uppercase", letterSpacing: "1px" }}>Agent</div>
          {agents.map((a, i) => (
            <div key={a.name} onClick={() => { setSelectedAgentIdx(i); setMessages([]); }} style={{
              padding: "8px 10px", borderRadius: 8, cursor: "pointer", fontSize: 13, marginBottom: 2,
              background: selectedAgentIdx === i ? "rgba(108,99,255,0.15)" : "transparent",
              color: selectedAgentIdx === i ? "var(--text)" : "var(--text2)",
              transition: "all 0.15s", display: "flex", alignItems: "center", gap: 8,
            }}>
              <span style={{ fontSize: 14 }}>{a.emoji}</span>
              <span>{a.name}</span>
            </div>
          ))}
        </div>
        <div style={{ padding: "12px 8px", borderBottom: "1px solid var(--border)" }}>
          <div style={{ fontSize: 11, color: "var(--text3)", padding: "0 8px", marginBottom: 8, textTransform: "uppercase", letterSpacing: "1px", display: "flex", justifyContent: "space-between" }}>
            <span>System Prompt</span>
            <span
              onClick={() => { setPromptDraft(selectedAgent.systemPrompt); setEditingPrompt(true); }}
              style={{ color: "var(--accent)", cursor: "pointer", textTransform: "none", letterSpacing: 0, fontSize: 11 }}
            >
              edit
            </span>
          </div>
          <div style={{ padding: "8px 10px", fontSize: 11, color: "var(--text2)", lineHeight: 1.5, fontStyle: "italic", maxHeight: 80, overflow: "hidden" }}>
            "{selectedAgent.systemPrompt.slice(0, 100)}{selectedAgent.systemPrompt.length > 100 ? "..." : ""}"
          </div>
        </div>
        <div style={{ flex: 1, overflowY: "auto", padding: "12px 8px" }}>
          <div style={{ fontSize: 11, color: "var(--text3)", padding: "0 8px", marginBottom: 8, textTransform: "uppercase", letterSpacing: "1px" }}>Provider</div>
          <div style={{ padding: "8px 10px", fontSize: 12, color: apiKey ? "var(--accent2)" : "var(--accent3)" }}>
            {apiKey ? `● Connected to ${providerLabel[provider]}` : "○ No API key set"}
          </div>
        </div>
        <div style={{ padding: "12px 10px", borderTop: "1px solid var(--border)" }}>
          <button className="btn btn-ghost" style={{ width: "100%", justifyContent: "center", fontSize: 12 }} onClick={() => setShowSettings(true)}>
            <Icon name="settings" size={13}/> API Settings
          </button>
        </div>
      </div>

      {/* Chat area */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", minWidth: 0 }}>
        {/* Agent header */}
        <div style={{ padding: "14px 20px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 12, background: "var(--bg2)", flexShrink: 0 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: "rgba(108,99,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>{selectedAgent.emoji}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 14, fontWeight: 600 }}>{selectedAgent.name}</div>
            <div style={{ fontSize: 11, color: apiKey ? "var(--accent2)" : "var(--accent3)", display: "flex", alignItems: "center", gap: 4 }}>
              <span style={{ width: 6, height: 6, borderRadius: "50%", background: apiKey ? "var(--accent2)" : "var(--accent3)", display: "inline-block" }}/>
              {apiKey ? `Active · ${model}` : "Not configured — add API key"}
            </div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn btn-ghost" style={{ padding: "6px 10px" }} onClick={clearChat} title="New chat"><Icon name="refresh" size={15}/></button>
            <button className="btn btn-ghost" style={{ padding: "6px 10px" }} onClick={() => setShowSettings(true)} title="API Settings"><Icon name="settings" size={15}/></button>
          </div>
        </div>

        {/* Messages */}
        <div style={{ flex: 1, overflowY: "auto", padding: "20px 24px", WebkitOverflowScrolling: "touch" }}>
          {messages.length === 0 && !loading && (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", textAlign: "center", padding: 24 }}>
              <div style={{ fontSize: 56, marginBottom: 16 }}>{selectedAgent.emoji}</div>
              <h3 style={{ fontSize: 22, fontWeight: 700, marginBottom: 8, fontFamily: "Syne, sans-serif" }}>{selectedAgent.name}</h3>
              <p style={{ fontSize: 14, color: "var(--text2)", maxWidth: 460, lineHeight: 1.6, marginBottom: 24 }}>
                Ask anything. I follow the system prompt set on the left — edit it to make me behave however you want.
              </p>
              {!apiKey && (
                <button className="btn btn-primary" onClick={() => setShowSettings(true)}>
                  <Icon name="settings" size={14}/> Add API Key to Start
                </button>
              )}
              {apiKey && (
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "center", maxWidth: 540 }}>
                  {[
                    "Write a viral tweet about productivity",
                    "Explain quantum computing simply",
                    "Draft a follow-up sales email",
                    "Give me 5 startup ideas for 2026",
                  ].map(s => (
                    <button key={s} className="btn btn-ghost" style={{ fontSize: 12, padding: "8px 14px" }}
                      onClick={() => { setInput(s); inputRef.current?.focus(); }}>
                      {s}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {messages.map((m) => (
            <div key={m.id} style={{
              display: "flex", gap: 12, marginBottom: 20,
              flexDirection: m.role === "user" ? "row-reverse" : "row",
              animation: "slide-up 0.3s cubic-bezier(0.22,1,0.36,1) both"
            }}>
              {m.role === "assistant" && (
                <div style={{ width: 32, height: 32, borderRadius: 10, background: "rgba(108,99,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0, marginTop: 2 }}>{selectedAgent.emoji}</div>
              )}
              <div style={{ maxWidth: "82%" }}>
                <div style={{
                  padding: "12px 16px", borderRadius: m.role === "user" ? "14px 4px 14px 14px" : "4px 14px 14px 14px",
                  background: m.role === "user" ? "linear-gradient(135deg, var(--accent), #9c63ff)" : "var(--surface2)",
                  border: m.role === "user" ? "none" : "1px solid var(--border)",
                  fontSize: 14, lineHeight: 1.65, wordBreak: "break-word"
                }} dangerouslySetInnerHTML={{ __html: renderContent(m.content) }}/>
                <div style={{ fontSize: 11, color: "var(--text3)", marginTop: 4, textAlign: m.role === "user" ? "right" : "left" }}>{m.time}</div>
              </div>
            </div>
          ))}
          {loading && (
            <div style={{ display: "flex", gap: 12, marginBottom: 20, alignItems: "center" }}>
              <div style={{ width: 32, height: 32, borderRadius: 10, background: "rgba(108,99,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>{selectedAgent.emoji}</div>
              <div className="glass" style={{ padding: "12px 16px", borderRadius: "4px 14px 14px 14px" }}>
                <div style={{ display: "flex", gap: 5, alignItems: "center" }}>
                  {[0,1,2].map(i => (
                    <div key={i} style={{
                      width: 7, height: 7, borderRadius: "50%", background: "var(--accent)",
                      animation: `typing 1.2s ease-in-out ${i * 0.2}s infinite`
                    }}/>
                  ))}
                </div>
              </div>
            </div>
          )}
          {error && (
            <div style={{ padding: "10px 14px", borderRadius: 10, background: "rgba(255,107,107,0.1)", border: "1px solid rgba(255,107,107,0.3)", color: "var(--accent3)", fontSize: 13, marginBottom: 12, display: "flex", alignItems: "center", gap: 10 }}>
              <span>⚠</span><span style={{ flex: 1 }}>{error}</span>
              <button onClick={() => setError("")} style={{ background: "none", border: "none", color: "var(--accent3)", cursor: "pointer" }}><Icon name="x" size={14}/></button>
            </div>
          )}
          <div ref={messagesEndRef}/>
        </div>

        {/* Input */}
        <div style={{ padding: "16px 20px", borderTop: "1px solid var(--border)", background: "var(--bg2)", flexShrink: 0 }}>
          <div className="glass2" style={{ borderRadius: 14, display: "flex", alignItems: "flex-end", gap: 10, padding: "10px 14px" }}>
            <textarea
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
              placeholder={apiKey ? `Ask ${selectedAgent.name} anything...` : "Add your API key to start"}
              style={{ flex: 1, resize: "none", border: "none", background: "transparent", minHeight: 22, maxHeight: 160, fontSize: 16, lineHeight: 1.5, outline: "none", color: "var(--text)", padding: "4px 0" }}
              rows={1}
            />
            <button className="btn btn-primary" style={{ padding: "8px 14px", flexShrink: 0, borderRadius: 10 }} onClick={sendMessage} disabled={!input.trim() || loading}>
              <Icon name="send" size={15}/>
            </button>
          </div>
          <div style={{ fontSize: 11, color: "var(--text3)", textAlign: "center", marginTop: 8 }}>
            Press <strong>Enter</strong> to send · <strong>Shift+Enter</strong> for new line · AI may make mistakes
          </div>
        </div>
      </div>

      {/* ── PROMPT EDITOR MODAL ── */}
      {editingPrompt && (
        <Modal onClose={() => setEditingPrompt(false)} title={`Edit System Prompt — ${selectedAgent.name}`}>
          <p style={{ fontSize: 13, color: "var(--text2)", marginBottom: 12, lineHeight: 1.6 }}>
            This is the instruction the AI follows. Be specific about role, tone, format, and constraints. The AI will use this for every reply in this chat.
          </p>
          <textarea
            value={promptDraft}
            onChange={e => setPromptDraft(e.target.value)}
            style={{ minHeight: 200, fontSize: 14, lineHeight: 1.6, marginBottom: 12 }}
            placeholder="You are an expert..."
          />
          <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
            <button className="btn btn-ghost" onClick={() => setEditingPrompt(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={savePrompt}>Save Prompt</button>
          </div>
        </Modal>
      )}

      {/* ── SETTINGS MODAL ── */}
      {showSettings && (
        <Modal onClose={() => setShowSettings(false)} title="API Settings">
          <div style={{ marginBottom: 20 }}>
            <label style={{ fontSize: 12, color: "var(--text2)", display: "block", marginBottom: 8, textTransform: "uppercase", letterSpacing: "1px" }}>Provider</label>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
              {[
                { id: "anthropic", label: "Anthropic", emoji: "🟣" },
                { id: "openai", label: "OpenAI", emoji: "🟢" },
                { id: "gemini", label: "Gemini", emoji: "🔵" },
              ].map(p => (
                <div key={p.id} onClick={() => { setProvider(p.id); setModel(modelOptions[p.id][0].id); }} style={{
                  padding: 12, borderRadius: 10, cursor: "pointer", textAlign: "center",
                  background: provider === p.id ? "rgba(108,99,255,0.15)" : "var(--surface)",
                  border: `1px solid ${provider === p.id ? "var(--accent)" : "var(--border)"}`,
                }}>
                  <div style={{ fontSize: 18, marginBottom: 4 }}>{p.emoji}</div>
                  <div style={{ fontSize: 12, fontWeight: 500 }}>{p.label}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ marginBottom: 20 }}>
            <label style={{ fontSize: 12, color: "var(--text2)", display: "block", marginBottom: 8, textTransform: "uppercase", letterSpacing: "1px" }}>Model</label>
            <select value={model} onChange={e => setModel(e.target.value)} style={{ background: "var(--surface)", padding: "10px 14px" }}>
              {modelOptions[provider].map(m => (
                <option key={m.id} value={m.id} style={{ background: "var(--bg2)" }}>{m.label}</option>
              ))}
            </select>
          </div>

          <div style={{ marginBottom: 16 }}>
            <label style={{ fontSize: 12, color: "var(--text2)", display: "block", marginBottom: 8, textTransform: "uppercase", letterSpacing: "1px" }}>API Key</label>
            <input
              type="password"
              value={apiKey}
              onChange={e => setApiKey(e.target.value)}
              placeholder={
                provider === "anthropic" ? "sk-ant-..." :
                provider === "openai" ? "sk-..." : "AIza..."
              }
            />
            <p style={{ fontSize: 11, color: "var(--text3)", marginTop: 8, lineHeight: 1.6 }}>
              Get your key from:{" "}
              {provider === "anthropic" && <a href="https://console.anthropic.com/settings/keys" target="_blank" rel="noopener" style={{ color: "var(--accent)" }}>console.anthropic.com</a>}
              {provider === "openai" && <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener" style={{ color: "var(--accent)" }}>platform.openai.com</a>}
              {provider === "gemini" && <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener" style={{ color: "var(--accent)" }}>aistudio.google.com</a>}
              <br/>Stored only in your browser (localStorage). Never sent anywhere except the API.
            </p>
          </div>

          <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
            <button className="btn btn-ghost" onClick={() => setShowSettings(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={saveSettings} disabled={!apiKey}>Save</button>
          </div>
        </Modal>
      )}
    </div>
  );
};

// ─── MODAL ────────────────────────────────────────────────────────────────────
const Modal = ({ children, onClose, title }) => (
  <div onClick={onClose} style={{
    position: "fixed", inset: 0, zIndex: 500,
    background: "rgba(0,0,0,0.7)", backdropFilter: "blur(8px)",
    display: "flex", alignItems: "center", justifyContent: "center",
    padding: 16, animation: "fade-in 0.2s ease both",
  }}>
    <div onClick={e => e.stopPropagation()} className="glass2" style={{
      width: "100%", maxWidth: 480, borderRadius: 18, padding: 24,
      maxHeight: "90vh", overflowY: "auto",
      animation: "slide-up 0.3s cubic-bezier(0.22,1,0.36,1) both",
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
        <h3 style={{ fontSize: 17, fontWeight: 700, fontFamily: "Syne, sans-serif" }}>{title}</h3>
        <button onClick={onClose} style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 8, padding: "6px", cursor: "pointer", display: "flex" }}>
          <Icon name="x" size={16}/>
        </button>
      </div>
      {children}
    </div>
  </div>
);

// ─── WORKFLOWS PAGE ───────────────────────────────────────────────────────────
const WorkflowsPage = () => {
  const [workflows] = useState([
    { id: 1, name: "Lead Nurture Sequence", status: "active", runs: 1240, trigger: "Form Submit", actions: 4, lastRun: "2m ago" },
    { id: 2, name: "Content Repurposer", status: "active", runs: 89, trigger: "New Blog Post", actions: 6, lastRun: "1h ago" },
    { id: 3, name: "Support Auto-Reply", status: "active", runs: 5600, trigger: "New Ticket", actions: 3, lastRun: "30s ago" },
    { id: 4, name: "Deal Stage Updater", status: "paused", runs: 234, trigger: "Email Opened", actions: 2, lastRun: "1d ago" },
    { id: 5, name: "Weekly AI Report", status: "active", runs: 12, trigger: "Schedule: Mon 9am", actions: 5, lastRun: "3d ago" },
  ]);

  return (
    <div style={{ padding: "24px 28px", overflowY: "auto", flex: 1 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <div>
          <h3 style={{ fontSize: 16, fontWeight: 700 }}>Workflow Automation</h3>
          <p style={{ fontSize: 13, color: "var(--text3)", marginTop: 2 }}>Build powerful automations without code</p>
        </div>
        <button className="btn btn-primary" style={{ fontSize: 13 }}><Icon name="plus" size={14}/> New Workflow</button>
      </div>

      {/* Templates */}
      <div className="glass" style={{ padding: 20, borderRadius: var_r2, marginBottom: 20 }}>
        <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 14, color: "var(--text2)" }}>Quick Start Templates</div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          {["Lead → AI Email → CRM", "Support Ticket → AI Reply → Slack", "New User → Onboard Sequence", "Blog → Social Posts → Schedule"].map(t => (
            <button key={t} className="btn btn-ghost" style={{ fontSize: 12, padding: "6px 12px" }}>{t}</button>
          ))}
        </div>
      </div>

      {/* Workflow Builder Visual */}
      <div className="glass" style={{ padding: 24, borderRadius: var_r2, marginBottom: 20 }}>
        <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 20 }}>Visual Builder Preview</div>
        <div style={{ display: "flex", alignItems: "center", gap: 0, overflowX: "auto", paddingBottom: 8 }}>
          {[
            { label: "Trigger", sublabel: "Form Submit", icon: "⚡", color: "#f5a623" },
            { label: "Filter", sublabel: "Lead Score > 50", icon: "🔍", color: "#a78bfa" },
            { label: "AI Agent", sublabel: "Sales AI writes email", icon: "🤖", color: "#6c63ff" },
            { label: "Send Email", sublabel: "via SendGrid", icon: "📧", color: "#00d4aa" },
            { label: "Update CRM", sublabel: "Move to Stage 2", icon: "📊", color: "#ff6b6b" },
          ].map((step, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", flexShrink: 0 }}>
              <div style={{
                padding: "14px 18px", borderRadius: 12, width: 140, textAlign: "center",
                background: step.color + "15", border: `1px solid ${step.color}30`,
                transition: "transform 0.2s", cursor: "pointer"
              }}
              onMouseEnter={e => e.currentTarget.style.transform = "translateY(-3px)"}
              onMouseLeave={e => e.currentTarget.style.transform = "none"}
              >
                <div style={{ fontSize: 22, marginBottom: 8 }}>{step.icon}</div>
                <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 3 }}>{step.label}</div>
                <div style={{ fontSize: 11, color: "var(--text3)" }}>{step.sublabel}</div>
              </div>
              {i < 4 && (
                <div style={{ width: 32, display: "flex", alignItems: "center", justifyContent: "center", color: "var(--text3)" }}>
                  →
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Workflows list */}
      <div className="glass" style={{ borderRadius: var_r2, overflow: "hidden" }}>
        <div style={{ padding: "14px 20px", borderBottom: "1px solid var(--border)", display: "flex", gap: 16, fontSize: 12, color: "var(--text3)", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px" }}>
          <div style={{ flex: 1 }}>Name</div>
          <div style={{ width: 80 }}>Status</div>
          <div style={{ width: 100 }}>Trigger</div>
          <div style={{ width: 80 }}>Runs</div>
          <div style={{ width: 100 }}>Last Run</div>
          <div style={{ width: 80 }}>Actions</div>
        </div>
        {workflows.map((w, i) => (
          <div key={w.id} style={{
            padding: "14px 20px", borderBottom: i < workflows.length - 1 ? "1px solid var(--border)" : "none",
            display: "flex", alignItems: "center", gap: 16, cursor: "pointer",
            transition: "background 0.15s"
          }}
          onMouseEnter={e => e.currentTarget.style.background = "var(--surface2)"}
          onMouseLeave={e => e.currentTarget.style.background = "transparent"}
          >
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 500 }}>{w.name}</div>
              <div style={{ fontSize: 12, color: "var(--text3)", marginTop: 2 }}>{w.actions} actions</div>
            </div>
            <div style={{ width: 80 }}>
              <span className="tag" style={{ fontSize: 11, background: w.status === "active" ? "rgba(0,212,170,0.1)" : "rgba(255,255,255,0.05)", color: w.status === "active" ? "var(--accent2)" : "var(--text3)" }}>
                {w.status}
              </span>
            </div>
            <div style={{ width: 100, fontSize: 13, color: "var(--text2)" }}>{w.trigger}</div>
            <div style={{ width: 80, fontSize: 13 }}>{w.runs.toLocaleString()}</div>
            <div style={{ width: 100, fontSize: 12, color: "var(--text3)" }}>{w.lastRun}</div>
            <div style={{ width: 80, display: "flex", gap: 8 }}>
              <button className="btn btn-ghost" style={{ padding: "4px 8px", fontSize: 12 }}>Edit</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─── CRM PAGE ─────────────────────────────────────────────────────────────────
const CRMPage = () => {
  const contacts = [
    { name: "Sarah Chen", company: "TechFlow", email: "s.chen@techflow.com", stage: "Proposal", value: "$12,000", score: 92 },
    { name: "Marcus R.", company: "Veloce Inc", email: "m.r@veloce.io", stage: "Qualified", value: "$8,500", score: 78 },
    { name: "Priya Sharma", company: "Apex Co", email: "priya@apex.co", stage: "Closed Won", value: "$24,000", score: 100 },
    { name: "Tom Wilson", company: "DataBridge", email: "tom@databridge.net", stage: "Discovery", value: "$4,200", score: 45 },
    { name: "Emma Liu", company: "Synapse AI", email: "emma@synapse.ai", stage: "Negotiation", value: "$16,800", score: 88 },
  ];

  const stageColors = {
    "Discovery": "#a78bfa", "Qualified": "#f5a623", "Proposal": "#6c63ff",
    "Negotiation": "#00d4aa", "Closed Won": "#34d399"
  };

  const pipeline = [
    { stage: "Discovery", count: 12, value: "$48K" },
    { stage: "Qualified", count: 8, value: "$72K" },
    { stage: "Proposal", count: 5, value: "$85K" },
    { stage: "Negotiation", count: 3, value: "$64K" },
    { stage: "Closed Won", count: 18, value: "$312K" },
  ];

  return (
    <div style={{ padding: "24px 28px", overflowY: "auto", flex: 1 }}>
      {/* Pipeline overview */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: 12, marginBottom: 24 }}>
        {pipeline.map((p, i) => (
          <div key={p.stage} className="glass" style={{ padding: "16px 18px", borderRadius: var_r2, borderTop: `2px solid ${stageColors[p.stage]}`, animation: `slide-up 0.5s cubic-bezier(0.22,1,0.36,1) ${i * 0.06}s both` }}>
            <div style={{ fontSize: 12, color: "var(--text3)", marginBottom: 8 }}>{p.stage}</div>
            <div style={{ fontSize: 22, fontWeight: 800, fontFamily: "Syne, sans-serif", marginBottom: 4 }}>{p.count}</div>
            <div style={{ fontSize: 13, color: stageColors[p.stage] }}>{p.value}</div>
          </div>
        ))}
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h3 style={{ fontSize: 15, fontWeight: 700 }}>Contacts</h3>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn btn-ghost" style={{ fontSize: 13 }}><Icon name="search" size={13}/> Filter</button>
          <button className="btn btn-primary" style={{ fontSize: 13 }}><Icon name="plus" size={13}/> Add Contact</button>
        </div>
      </div>

      <div className="glass" style={{ borderRadius: var_r2, overflow: "hidden" }}>
        <div style={{ padding: "12px 20px", borderBottom: "1px solid var(--border)", display: "grid", gridTemplateColumns: "1fr 120px 80px 100px 80px 100px", gap: 12, fontSize: 11, color: "var(--text3)", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px" }}>
          <div>Contact</div><div>Company</div><div>Stage</div><div>Value</div><div>Score</div><div>Action</div>
        </div>
        {contacts.map((c, i) => (
          <div key={c.name} style={{
            padding: "14px 20px", borderBottom: i < contacts.length - 1 ? "1px solid var(--border)" : "none",
            display: "grid", gridTemplateColumns: "1fr 120px 80px 100px 80px 100px", gap: 12, alignItems: "center",
            cursor: "pointer", transition: "background 0.15s"
          }}
          onMouseEnter={e => e.currentTarget.style.background = "var(--surface2)"}
          onMouseLeave={e => e.currentTarget.style.background = "transparent"}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 32, height: 32, borderRadius: "50%", background: "linear-gradient(135deg, var(--accent), var(--accent2))", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, flexShrink: 0 }}>
                {c.name.split(" ").map(n => n[0]).join("")}
              </div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{c.name}</div>
                <div style={{ fontSize: 11, color: "var(--text3)" }}>{c.email}</div>
              </div>
            </div>
            <div style={{ fontSize: 13, color: "var(--text2)" }}>{c.company}</div>
            <span className="tag" style={{ fontSize: 11, background: stageColors[c.stage] + "15", color: stageColors[c.stage], width: "fit-content" }}>{c.stage}</span>
            <div style={{ fontSize: 13, fontWeight: 600 }}>{c.value}</div>
            <div>
              <div style={{ height: 6, background: "var(--surface2)", borderRadius: 3, overflow: "hidden" }}>
                <div style={{ height: "100%", width: `${c.score}%`, background: c.score > 80 ? "var(--accent2)" : "var(--accent4)", borderRadius: 3 }}/>
              </div>
              <div style={{ fontSize: 10, color: "var(--text3)", marginTop: 2 }}>{c.score}</div>
            </div>
            <button className="btn btn-ghost" style={{ fontSize: 12, padding: "5px 10px" }}>View</button>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─── FILES PAGE ───────────────────────────────────────────────────────────────
const FilesPage = () => {
  const [dragging, setDragging] = useState(false);
  const files = [
    { name: "Q3 Report.pdf", type: "PDF", size: "2.4 MB", uploaded: "May 7", analyzed: true },
    { name: "Brand Guidelines.pdf", type: "PDF", size: "8.1 MB", uploaded: "May 6", analyzed: true },
    { name: "Customer Data.xlsx", type: "Excel", size: "1.2 MB", uploaded: "May 5", analyzed: false },
    { name: "Product Images.zip", type: "Archive", size: "45 MB", uploaded: "May 4", analyzed: false },
    { name: "Campaign Brief.docx", type: "Word", size: "0.8 MB", uploaded: "May 3", analyzed: true },
  ];

  const typeColors = { "PDF": "#ff6b6b", "Excel": "#34d399", "Archive": "#f5a623", "Word": "#6c63ff" };
  const typeEmoji = { "PDF": "📄", "Excel": "📊", "Archive": "📦", "Word": "📝" };

  return (
    <div style={{ padding: "24px 28px", overflowY: "auto", flex: 1 }}>
      {/* Upload zone */}
      <div className="glass" style={{
        borderRadius: var_r2, padding: 40, textAlign: "center", marginBottom: 24,
        border: `2px dashed ${dragging ? "var(--accent)" : "var(--border)"}`,
        background: dragging ? "rgba(108,99,255,0.05)" : "var(--surface)",
        transition: "all 0.2s", cursor: "pointer"
      }}
      onDragOver={e => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={() => setDragging(false)}
      >
        <div style={{ width: 52, height: 52, borderRadius: 16, background: "rgba(108,99,255,0.15)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}>
          <Icon name="upload" size={24} color="var(--accent)"/>
        </div>
        <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 8 }}>Drop files here or click to upload</h3>
        <p style={{ fontSize: 14, color: "var(--text2)", marginBottom: 16 }}>Supports PDF, DOCX, XLSX, images up to 100MB</p>
        <button className="btn btn-primary" style={{ fontSize: 13 }}>Choose Files</button>
      </div>

      {/* AI Capabilities */}
      <div className="glass" style={{ padding: 20, borderRadius: var_r2, marginBottom: 24 }}>
        <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 12 }}>AI can do with your files:</div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          {["📋 Summarize documents", "🔍 Extract key data", "❓ Ask questions about content", "📊 Create reports", "🌐 Translate content", "✏️ Rewrite & improve"].map(cap => (
            <span key={cap} className="tag" style={{ background: "var(--surface2)", color: "var(--text2)", fontSize: 12 }}>{cap}</span>
          ))}
        </div>
      </div>

      {/* Files list */}
      <div className="glass" style={{ borderRadius: var_r2, overflow: "hidden" }}>
        <div style={{ padding: "12px 20px", borderBottom: "1px solid var(--border)", display: "flex", justifyContent: "space-between" }}>
          <span style={{ fontSize: 14, fontWeight: 600 }}>Uploaded Files</span>
          <span style={{ fontSize: 12, color: "var(--text3)" }}>{files.length} files · 57.5 MB</span>
        </div>
        {files.map((f, i) => (
          <div key={f.name} style={{
            padding: "14px 20px", borderBottom: i < files.length - 1 ? "1px solid var(--border)" : "none",
            display: "flex", alignItems: "center", gap: 14, cursor: "pointer",
            transition: "background 0.15s"
          }}
          onMouseEnter={e => e.currentTarget.style.background = "var(--surface2)"}
          onMouseLeave={e => e.currentTarget.style.background = "transparent"}
          >
            <div style={{ width: 40, height: 40, borderRadius: 10, background: typeColors[f.type] + "15", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 }}>
              {typeEmoji[f.type]}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 500 }}>{f.name}</div>
              <div style={{ fontSize: 12, color: "var(--text3)" }}>{f.size} · {f.uploaded}</div>
            </div>
            {f.analyzed && (
              <span className="tag" style={{ fontSize: 11, background: "rgba(0,212,170,0.1)", color: "var(--accent2)" }}>
                <Icon name="check" size={10} color="var(--accent2)"/> AI Analyzed
              </span>
            )}
            <div style={{ display: "flex", gap: 8 }}>
              <button className="btn btn-ghost" style={{ fontSize: 12, padding: "5px 10px" }}>
                <Icon name="message" size={12}/> Ask AI
              </button>
              <button className="btn btn-ghost" style={{ fontSize: 12, padding: "5px 10px" }}>View</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─── ANALYTICS PAGE ───────────────────────────────────────────────────────────
const AnalyticsPage = () => {
  const weeklyData = [28,42,35,58,47,72,64,80,71,88,76,95];
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

  return (
    <div style={{ padding: "24px 28px", overflowY: "auto", flex: 1 }}>
      <div className="grid-4" style={{ marginBottom: 24 }}>
        {[
          { l: "Total AI Tokens", v: "24.8M", c: "+34%", color: "var(--accent)" },
          { l: "Avg Response Time", v: "1.2s", c: "+8%", color: "var(--accent2)" },
          { l: "Success Rate", v: "98.4%", c: "+2.1%", color: "#34d399" },
          { l: "Cost Savings", v: "$8,420", c: "+44%", color: "var(--accent4)" },
        ].map((s, i) => (
          <div key={s.l} className="glass" style={{ padding: "20px 22px", borderRadius: var_r2, animation: `slide-up 0.5s cubic-bezier(0.22,1,0.36,1) ${i * 0.07}s both` }}>
            <div style={{ fontSize: 12, color: "var(--text3)", marginBottom: 8 }}>{s.l}</div>
            <div style={{ fontSize: 26, fontWeight: 800, fontFamily: "Syne, sans-serif", marginBottom: 6 }}>{s.v}</div>
            <span style={{ fontSize: 12, color: "var(--accent2)", background: "rgba(0,212,170,0.1)", padding: "2px 8px", borderRadius: 100 }}>↑ {s.c}</span>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 20, marginBottom: 20 }}>
        <div className="glass" style={{ padding: 24, borderRadius: var_r2 }}>
          <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 20 }}>AI Usage Over Time</h3>
          <div style={{ display: "flex", alignItems: "flex-end", gap: 8, height: 180, marginBottom: 8 }}>
            {weeklyData.map((h, i) => (
              <div key={i} style={{ flex: 1, height: `${h}%`, borderRadius: "4px 4px 0 0", background: `linear-gradient(to top, var(--accent), var(--accent2))`, opacity: 0.7 + i * 0.025 }}/>
            ))}
          </div>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            {months.map(m => <span key={m} style={{ fontSize: 10, color: "var(--text3)" }}>{m}</span>)}
          </div>
        </div>

        <div className="glass" style={{ padding: 24, borderRadius: var_r2 }}>
          <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 20 }}>Model Usage Split</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {[
              { name: "Claude Sonnet", pct: 48, color: "#a78bfa" },
              { name: "GPT-4o", pct: 31, color: "#34d399" },
              { name: "Gemini Pro", pct: 14, color: "#60a5fa" },
              { name: "Claude Haiku", pct: 7, color: "#f472b6" },
            ].map(m => (
              <div key={m.name}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                  <span style={{ fontSize: 13, color: "var(--text2)" }}>{m.name}</span>
                  <span style={{ fontSize: 12, fontWeight: 600 }}>{m.pct}%</span>
                </div>
                <div style={{ height: 6, background: "var(--surface2)", borderRadius: 3 }}>
                  <div style={{ height: "100%", width: `${m.pct}%`, background: m.color, borderRadius: 3 }}/>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="glass" style={{ padding: 24, borderRadius: var_r2 }}>
        <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 20 }}>Agent Performance</h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(6,1fr)", gap: 16 }}>
          {[
            { name: "Marketing", emoji: "📣", msgs: 1240, rate: "96%" },
            { name: "Sales", emoji: "💰", msgs: 890, rate: "94%" },
            { name: "Research", emoji: "🔬", msgs: 567, rate: "98%" },
            { name: "Support", emoji: "💬", msgs: 2100, rate: "99%" },
            { name: "Social", emoji: "📱", msgs: 450, rate: "93%" },
            { name: "Copy", emoji: "✍️", msgs: 780, rate: "95%" },
          ].map(a => (
            <div key={a.name} className="glass" style={{ padding: "16px", borderRadius: var_r, textAlign: "center" }}>
              <div style={{ fontSize: 24, marginBottom: 8 }}>{a.emoji}</div>
              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4 }}>{a.name}</div>
              <div style={{ fontSize: 11, color: "var(--text3)", marginBottom: 6 }}>{a.msgs.toLocaleString()} msgs</div>
              <div style={{ fontSize: 13, color: "var(--accent2)", fontWeight: 700 }}>{a.rate}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const var_r = "var(--r)";

// ─── SETTINGS PAGE ────────────────────────────────────────────────────────────
const SettingsPage = () => {
  const [plan] = useState("Pro");
  const [tab, setTab] = useState("profile");
  const tabs = ["profile", "team", "billing", "api", "security"];

  return (
    <div style={{ padding: "24px 28px", overflowY: "auto", flex: 1, display: "flex", gap: 24 }}>
      {/* Tab sidebar */}
      <div style={{ width: 180, flexShrink: 0 }}>
        {tabs.map(t => (
          <div key={t} onClick={() => setTab(t)} style={{
            padding: "9px 12px", borderRadius: 8, marginBottom: 2, cursor: "pointer",
            background: tab === t ? "rgba(108,99,255,0.15)" : "transparent",
            color: tab === t ? "var(--text)" : "var(--text2)", fontSize: 14,
            transition: "all 0.15s", textTransform: "capitalize"
          }}>
            {t}
          </div>
        ))}
      </div>

      {/* Content */}
      <div style={{ flex: 1 }}>
        {tab === "profile" && (
          <div>
            <div className="glass" style={{ padding: 24, borderRadius: var_r2, marginBottom: 16 }}>
              <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 20 }}>Profile</h3>
              <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 24 }}>
                <div style={{ width: 64, height: 64, borderRadius: 18, background: "linear-gradient(135deg, var(--accent), var(--accent2))", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, fontWeight: 700 }}>JD</div>
                <button className="btn btn-ghost" style={{ fontSize: 13 }}>Change Avatar</button>
              </div>
              <div className="grid-2" style={{ gap: 16, marginBottom: 16 }}>
                <div>
                  <label style={{ fontSize: 12, color: "var(--text2)", display: "block", marginBottom: 6 }}>First Name</label>
                  <input defaultValue="John"/>
                </div>
                <div>
                  <label style={{ fontSize: 12, color: "var(--text2)", display: "block", marginBottom: 6 }}>Last Name</label>
                  <input defaultValue="Doe"/>
                </div>
              </div>
              <div style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 12, color: "var(--text2)", display: "block", marginBottom: 6 }}>Email</label>
                <input defaultValue="john@company.com"/>
              </div>
              <button className="btn btn-primary" style={{ fontSize: 13 }}>Save Changes</button>
            </div>
          </div>
        )}
        {tab === "billing" && (
          <div>
            <div className="glass" style={{ padding: 24, borderRadius: var_r2, marginBottom: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
                <div>
                  <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 4 }}>Current Plan</h3>
                  <p style={{ fontSize: 13, color: "var(--text2)" }}>Billed monthly</p>
                </div>
                <span className="tag" style={{ background: "rgba(108,99,255,0.15)", color: "var(--accent)", border: "1px solid rgba(108,99,255,0.3)" }}>
                  <Icon name="crown" size={12} color="var(--accent)"/> {plan}
                </span>
              </div>
              <div style={{ fontSize: 36, fontWeight: 800, fontFamily: "Syne, sans-serif", marginBottom: 4 }}>$49<span style={{ fontSize: 16, fontWeight: 400, color: "var(--text2)" }}>/mo</span></div>
              <p style={{ fontSize: 13, color: "var(--text3)", marginBottom: 20 }}>Next billing: June 7, 2026</p>
              <div style={{ display: "flex", gap: 10 }}>
                <button className="btn btn-primary" style={{ fontSize: 13 }}>Upgrade to Agency</button>
                <button className="btn btn-ghost" style={{ fontSize: 13 }}>Manage Billing</button>
              </div>
            </div>
            <div className="glass" style={{ padding: 24, borderRadius: var_r2 }}>
              <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>Usage This Month</h3>
              {[["AI Messages", "8,240 / Unlimited"], ["Workflows", "12 / Unlimited"], ["Team Members", "4 / 5"], ["Storage", "2.4 GB / 10 GB"]].map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
                  <span style={{ fontSize: 14, color: "var(--text2)" }}>{k}</span>
                  <span style={{ fontSize: 14, fontWeight: 500 }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        )}
        {tab === "api" && (
          <div className="glass" style={{ padding: 24, borderRadius: var_r2 }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 20 }}>API Keys</h3>
            {[["OpenAI API Key", "sk-...4f8a"], ["Anthropic API Key", "sk-ant-...9b2c"], ["Gemini API Key", "AIza...7d1e"]].map(([name, val]) => (
              <div key={name} style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 12, color: "var(--text2)", display: "block", marginBottom: 6 }}>{name}</label>
                <div style={{ display: "flex", gap: 8 }}>
                  <input defaultValue={val} type="password" style={{ flex: 1 }}/>
                  <button className="btn btn-ghost" style={{ padding: "8px 12px" }}><Icon name="copy" size={14}/></button>
                </div>
              </div>
            ))}
            <button className="btn btn-primary" style={{ fontSize: 13 }}>Save API Keys</button>
          </div>
        )}
        {(tab === "team" || tab === "security") && (
          <div className="glass" style={{ padding: 24, borderRadius: var_r2, textAlign: "center" }}>
            <div style={{ fontSize: 40, marginBottom: 16 }}>{tab === "team" ? "👥" : "🔐"}</div>
            <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 8 }}>{tab === "team" ? "Team Management" : "Security Settings"}</h3>
            <p style={{ fontSize: 14, color: "var(--text2)", marginBottom: 20 }}>Full {tab} management panel available in production build.</p>
            <button className="btn btn-primary" style={{ fontSize: 13 }}>Configure</button>
          </div>
        )}
      </div>
    </div>
  );
};

// ─── APP SHELL ────────────────────────────────────────────────────────────────
const AppShell = ({ page, onNav, children }) => {
  const [collapsed, setCollapsed] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const isMobile = useIsMobile();
  const pageTitles = {
    dashboard: ["Dashboard", "Welcome back, John 👋"],
    agents: ["AI Agents", "Manage your intelligent workforce"],
    chat: ["AI Chat", "Powered by Claude, GPT-4, and Gemini"],
    workflows: ["Workflows", "Automate your business processes"],
    crm: ["CRM", "Manage your contacts and pipeline"],
    files: ["Files", "Upload and analyze documents with AI"],
    analytics: ["Analytics", "Monitor performance and usage"],
    settings: ["Settings", "Manage your account and preferences"],
  };
  const [title, subtitle] = pageTitles[page] || ["Dashboard", ""];

  if (isMobile) {
    return (
      <div style={{
        display: "flex", flexDirection: "column",
        height: "-webkit-fill-available", minHeight: "100vh",
        overflow: "hidden",
        paddingTop: "env(safe-area-inset-top, 0px)",
      }}>
        {/* Mobile top bar */}
        <div style={{
          padding: "10px 16px",
          borderBottom: "1px solid var(--border)",
          display: "flex", alignItems: "center", justifyContent: "space-between",
          background: "var(--bg2)", flexShrink: 0
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <button className="btn btn-ghost" style={{ padding: "7px 9px" }} onClick={() => setDrawerOpen(true)}>
              <Icon name="menu" size={18}/>
            </button>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <div style={{ width: 26, height: 26, borderRadius: 7, background: "linear-gradient(135deg, var(--accent), var(--accent2))", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Icon name="brain" size={13} color="#fff"/>
              </div>
              <span style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: 13 }}>WHAT</span>
            </div>
          </div>
          <div style={{ display: "flex", gap: 6 }}>
            <button className="btn btn-ghost" style={{ padding: "6px 8px", position: "relative" }}>
              <Icon name="bell" size={16}/>
              <span style={{ position: "absolute", top: 5, right: 5, width: 6, height: 6, borderRadius: "50%", background: "var(--accent3)", border: "2px solid var(--bg2)" }}/>
            </button>
            <button className="btn btn-primary" style={{ padding: "6px 10px", fontSize: 12 }}>
              <Icon name="plus" size={13}/>
            </button>
          </div>
        </div>

        {/* Page title strip (not for chat) */}
        {page !== "chat" && (
          <div style={{ padding: "10px 16px 8px", borderBottom: "1px solid var(--border)", background: "var(--bg2)", flexShrink: 0 }}>
            <h2 style={{ fontSize: 15, fontWeight: 700, letterSpacing: "-0.3px" }}>{title}</h2>
            {subtitle && <p style={{ fontSize: 11, color: "var(--text3)", marginTop: 1 }}>{subtitle}</p>}
          </div>
        )}

        {/* Content - leaves room for bottom nav */}
        <div style={{
          flex: 1,
          overflow: page === "chat" ? "hidden" : "auto",
          WebkitOverflowScrolling: "touch",
          display: "flex", flexDirection: "column",
          paddingBottom: "calc(64px + env(safe-area-inset-bottom, 0px))",
        }}>
          {children}
        </div>

        {/* Bottom nav */}
        <BottomNav page={page} onNav={onNav}/>

        {/* Drawer */}
        {drawerOpen && <MobileDrawer page={page} onNav={onNav} onClose={() => setDrawerOpen(false)}/>}
      </div>
    );
  }

  return (
    <div style={{ display: "flex", height: "-webkit-fill-available", minHeight: "100vh", overflow: "hidden" }}>
      <Sidebar page={page} onNav={onNav} collapsed={collapsed} onToggle={() => setCollapsed(c => !c)}/>
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        {page !== "chat" && <Topbar title={title} subtitle={subtitle}/>}
        <div style={{ flex: 1, overflow: page === "chat" ? "hidden" : "auto", WebkitOverflowScrolling: "touch", display: "flex", flexDirection: "column" }}>
          {children}
        </div>
      </div>
    </div>
  );
};

// ─── ROOT APP ─────────────────────────────────────────────────────────────────
export default function WhatApp() {
  const [page, setPage] = useState("landing");

  const pageComponents = {
    dashboard: <DashboardPage onNav={setPage}/>,
    agents: <AgentsPage onNav={setPage}/>,
    chat: <ChatPage/>,
    workflows: <WorkflowsPage/>,
    crm: <CRMPage/>,
    files: <FilesPage/>,
    analytics: <AnalyticsPage/>,
    settings: <SettingsPage/>,
  };

  const isDashboard = page !== "landing";

  return (
    <>
      <AnimatedBg/>
      {page === "landing" ? (
        <>
          <Navbar onNav={setPage} page={page}/>
          <div style={{ position: "relative", zIndex: 1 }}>
            <LandingPage onNav={setPage}/>
          </div>
        </>
      ) : (
        <div style={{ position: "relative", zIndex: 1, height: "100vh" }}>
          <AppShell page={page} onNav={setPage}>
            {pageComponents[page]}
          </AppShell>
        </div>
      )}
    </>
  );
}
