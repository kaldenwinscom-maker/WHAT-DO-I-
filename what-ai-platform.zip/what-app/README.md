# WHAT — AI Agency Platform

> A real, working AI agency app. Bring your own API key (Claude / GPT-4 / Gemini) and chat with custom agents, fuse them into hybrids, build workflows, and more.

![Next.js](https://img.shields.io/badge/Next.js-15-black?logo=next.js)
![React](https://img.shields.io/badge/React-19-61dafb?logo=react)
![TypeScript](https://img.shields.io/badge/TypeScript-5-3178c6?logo=typescript)
![iOS](https://img.shields.io/badge/iOS-Compatible-000?logo=apple)
![License](https://img.shields.io/badge/License-MIT-green)

---

## ✨ What's working right now

- 💬 **Real AI chat** — works with Anthropic, OpenAI, and Google Gemini APIs
- 📝 **Custom system prompts** — make any agent behave however you want
- ⚡ **Agent Fusion Lab** — combine 2 agents → 1 hybrid super-agent
- 🧠 **Live neural visualizer** — watch the agent's "mind" pulse in real-time
- 🎙️ **Voice clone (UI)** — animated waveform recording demo
- ⬆️ **Agent evolution** — power level system with star badges
- 📊 **Dashboard** with revenue charts, AI activity, and agent stats
- 🔄 **Workflow automation** — visual builder with triggers and actions
- 👥 **CRM** — pipeline, contacts, lead scoring
- 📁 **File upload UI** — drag-and-drop with AI analysis flags
- 📈 **Analytics** — token usage, model split, agent performance
- 📱 **Fully iOS compatible** — safe area insets, momentum scroll, bottom nav

---

## 🚀 Quick Start

### 1. Clone & install

```bash
git clone https://github.com/YOUR_USERNAME/what-ai-platform.git
cd what-ai-platform
npm install
```

### 2. Run

```bash
npm run dev
```

Open **http://localhost:3000** — done.

### 3. Add your API key (in the app)

1. Click **Chat** in the sidebar
2. Click the **⚙ API Settings** button
3. Pick your provider (Anthropic, OpenAI, or Gemini)
4. Pick a model
5. Paste your API key → **Save**

Your key is stored **only in your browser's localStorage**. It never touches a server unless it's your provider's API.

### 4. Start chatting

Type **literally anything**. The AI responds for real. Edit the **system prompt** on the left to make any agent behave however you want — pirate, legal advisor, code reviewer, creative writer, anything.

---

## 🔑 Get an API key (free credits available)

| Provider | Sign up |
|----------|---------|
| **Anthropic** (Claude) | [console.anthropic.com](https://console.anthropic.com/settings/keys) |
| **OpenAI** (GPT-4o) | [platform.openai.com](https://platform.openai.com/api-keys) |
| **Google** (Gemini) | [aistudio.google.com](https://aistudio.google.com/app/apikey) — has a generous free tier |

---

## 🌐 Deploy to Vercel (free, 2 minutes)

The fastest way to get your app live:

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

1. Push this repo to GitHub
2. Go to [vercel.com/new](https://vercel.com/new)
3. Import your repo
4. Click **Deploy** — no env vars needed (users bring their own keys)

You'll get a URL like `your-app.vercel.app` immediately.

### Other free hosting options

- **Netlify** — works the same, drop the repo
- **Cloudflare Pages** — free tier, great performance
- **Railway** — `railway up`
- **Render** — connect GitHub, auto-deploy

---

## 📁 Project Structure

```
what-ai-platform/
├── src/
│   ├── app/
│   │   ├── layout.tsx        # Root layout with iOS viewport meta
│   │   ├── page.tsx          # Home page
│   │   └── globals.css       # All styles + design tokens
│   ├── components/
│   │   └── WhatApp.tsx       # Main app — landing, dashboard, chat, agents, etc.
│   └── lib/
│       └── utils.ts          # Helper functions
├── public/                   # Static assets (icons go here)
├── .env.example              # Environment template (optional)
├── .gitignore
├── next.config.ts
├── package.json
├── tsconfig.json
└── README.md
```

---

## 🛠 Push to GitHub

```bash
cd what-ai-platform
git init
git add .
git commit -m "Initial commit — WHAT AI Platform"

# Create a new repo on github.com first, then:
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/what-ai-platform.git
git push -u origin main
```

---

## 🎨 Customize

### Change the brand
Edit `src/components/WhatApp.tsx` — search for `WHAT` and replace.

### Change the colors
Edit `src/app/globals.css` — the `:root` block has every CSS variable:

```css
--accent: #6c63ff;     /* primary brand */
--accent2: #00d4aa;    /* secondary */
--bg: #060810;         /* background */
```

### Add a new agent
Find the `agents` array in `WhatApp.tsx` (in `ChatPage`) and add an entry:

```js
{ name: "Legal AI", emoji: "⚖️", systemPrompt: "You are a contract lawyer..." }
```

### Add a new page
Add it to the `pageComponents` map in the `App` component at the bottom of `WhatApp.tsx`.

---

## 🧠 How the AI integration works

When you send a message:

1. The app builds the message history client-side
2. It calls the provider's API directly from the browser:
   - **Anthropic**: `POST https://api.anthropic.com/v1/messages` (uses `anthropic-dangerous-direct-browser-access: true`)
   - **OpenAI**: `POST https://api.openai.com/v1/chat/completions`
   - **Gemini**: `POST https://generativelanguage.googleapis.com/v1beta/models/.../generateContent`
3. Your API key + system prompt + chat history get sent
4. The response is rendered with markdown support (bold, italic, code)
5. Errors are caught and displayed inline

---

## 🔐 Security notes

- **API keys never touch a server you don't control.** They're stored in `localStorage` on the user's device.
- **For production with paying users**, consider building a server proxy so users don't need their own keys. Add `app/api/chat/route.ts` and store keys in environment variables on Vercel.
- The markdown renderer **escapes HTML** before applying formatting, so it's safe from injection.

---

## 📦 Tech Stack

| Layer | Tech |
|-------|------|
| Framework | Next.js 15 (App Router) |
| UI | React 19 + custom CSS |
| Language | TypeScript |
| AI | OpenAI / Anthropic / Google Gemini APIs |
| State | React hooks + localStorage |
| Deployment | Vercel (recommended) |

---

## 📄 License

MIT — do whatever you want with it.

---

**Made with ☕ + AI.** If you build something cool with this, I'd love to see it.
